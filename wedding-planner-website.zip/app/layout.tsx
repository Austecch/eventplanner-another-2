import type { Metadata } from 'next'
import { Playfair_Display, Jost, Cormorant_Garamond } from 'next/font/google'
import './globals.css'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'

const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-playfair',
  display: 'swap',
})

const jost = Jost({
  subsets: ['latin'],
  variable: '--font-jost',
  weight: ['200', '300', '400', '500', '600'],
  display: 'swap',
})

const cormorant = Cormorant_Garamond({
  subsets: ['latin'],
  variable: '--font-cormorant',
  weight: ['300', '400', '500', '600'],
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Veil & Bloom | Luxury Wedding Planning — New Jersey',
  description:
    'Veil & Bloom crafts timeless, cinematic weddings across New Jersey. Full planning, partial planning, day-of coordination, and destination weddings.',
  keywords:
    'luxury wedding planner New Jersey, NJ wedding planning, high-end wedding coordinator, bridal planning NJ',
}

export const viewport = {
  themeColor: '#C9A84C',
}

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html
      lang="en"
      className={`${playfair.variable} ${jost.variable} ${cormorant.variable}`}
    >
      <body className="antialiased bg-[#FFFDF7] text-[#2C2C2C]">
        <Navbar />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  )
}
