'use client'

import { useState } from 'react'
import Link from 'next/link'
import {
  LayoutDashboard, Calendar, Users, Package, BarChart2,
  Settings, LogOut, Check, X, Clock, ChevronRight,
  Bell, Menu, TrendingUp, DollarSign, Star, AlertCircle
} from 'lucide-react'

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', id: 'dashboard' },
  { icon: Calendar, label: 'Bookings', id: 'bookings' },
  { icon: Users, label: 'Clients', id: 'clients' },
  { icon: Package, label: 'Vendors', id: 'vendors' },
  { icon: BarChart2, label: 'Analytics', id: 'analytics' },
  { icon: Settings, label: 'Settings', id: 'settings' },
]

const bookings = [
  { couple: 'Sophia & James Hartley', date: 'Oct 4, 2025', service: 'Full Planning', status: 'active', planner: 'Isabelle', venue: 'Park Chateau Estate', budget: '$85,000' },
  { couple: 'Mei & David Zhang', date: 'May 10, 2025', service: 'Day-of Coordination', status: 'active', planner: 'Naomi', venue: 'Skylands Manor', budget: '$42,000' },
  { couple: 'Layla & Marcus Brown', date: 'Jul 19, 2025', service: 'Partial Planning', status: 'pending', planner: 'Unassigned', venue: 'TBD', budget: '$60,000' },
  { couple: 'Chloe & Ethan Davis', date: 'Aug 30, 2025', service: 'Full Planning', status: 'pending', planner: 'Unassigned', venue: 'TBD', budget: '$110,000' },
  { couple: 'Natalie & Ryan Pierce', date: 'Nov 22, 2025', service: 'Full Planning', status: 'inquiry', planner: 'Unassigned', venue: 'TBD', budget: '$75,000' },
  { couple: 'Grace & Oliver Kim', date: 'Mar 14, 2026', service: 'Destination', status: 'inquiry', planner: 'Unassigned', venue: 'Amalfi Coast', budget: '$200,000+' },
]

const vendors = [
  { name: 'Bloom & Co. Florals', category: 'Florals', contact: 'hello@bloomandco.com', rating: 5, weddings: 24, status: 'preferred' },
  { name: 'Golden Lens Studio', category: 'Photography', contact: 'shoot@goldenlens.com', rating: 5, weddings: 18, status: 'preferred' },
  { name: 'Aria Catering Co.', category: 'Catering', contact: 'events@ariacatering.com', rating: 4, weddings: 31, status: 'approved' },
  { name: 'Strings & Things Music', category: 'Entertainment', contact: 'hello@stringsthings.com', rating: 5, weddings: 15, status: 'preferred' },
  { name: 'Park Chateau Estate', category: 'Venue', contact: 'events@parkchateau.com', rating: 5, weddings: 12, status: 'preferred' },
  { name: 'Celestial Hair & Makeup', category: 'Beauty', contact: 'book@celestialbeauty.com', rating: 4, weddings: 28, status: 'approved' },
]

const inquiries = [
  { couple: 'Layla & Marcus Brown', date: 'May 10, 2025', service: 'Partial Planning', budget: '$60,000', id: 'inq-001' },
  { couple: 'Grace & Oliver Kim', date: 'May 9, 2025', service: 'Destination Wedding', budget: '$200,000+', id: 'inq-002' },
]

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [approved, setApproved] = useState<string[]>([])
  const [rejected, setRejected] = useState<string[]>([])

  const SidebarContent = () => (
    <>
      <div className="px-6 py-8 border-b" style={{ borderColor: 'rgba(201,168,76,0.2)' }}>
        <div>
          <div className="text-xl tracking-wider mb-1" style={{ fontFamily: 'var(--font-playfair)', color: '#F5E6C8' }}>
            Veil &amp; Bloom
          </div>
          <div className="text-[0.55rem] tracking-[0.3em] uppercase" style={{ color: '#C9A84C' }}>
            Admin Panel
          </div>
        </div>
      </div>
      <nav className="px-3 py-6 flex-1">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => { setActiveTab(item.id); setSidebarOpen(false) }}
            className="w-full flex items-center gap-3 px-4 py-3 mb-1 text-left transition-all duration-300"
            style={{
              background: activeTab === item.id ? 'rgba(201,168,76,0.15)' : 'transparent',
              borderLeft: activeTab === item.id ? '2px solid #C9A84C' : '2px solid transparent',
              color: activeTab === item.id ? '#C9A84C' : '#7A7068',
            }}
          >
            <item.icon size={15} />
            <span className="text-xs tracking-[0.1em]" style={{ fontFamily: 'var(--font-jost)', fontWeight: 300 }}>{item.label}</span>
          </button>
        ))}
      </nav>
      <div className="px-6 pb-8">
        <Link href="/" className="flex items-center gap-3 text-xs transition-colors hover:text-[#C9A84C]"
          style={{ color: '#5C5248', fontFamily: 'var(--font-jost)' }}>
          <LogOut size={13} /> Sign Out
        </Link>
      </div>
    </>
  )

  const statusBadge = (status: string) => {
    const map: Record<string, { label: string; bg: string; color: string }> = {
      active: { label: 'Active', bg: 'rgba(201,168,76,0.15)', color: '#9B7A2F' },
      pending: { label: 'Pending', bg: 'rgba(226,201,126,0.15)', color: '#7A7068' },
      inquiry: { label: 'Inquiry', bg: 'rgba(232,196,196,0.3)', color: '#8B5050' },
    }
    const s = map[status] || map.inquiry
    return (
      <span
        className="text-[0.55rem] tracking-[0.15em] uppercase px-2 py-0.5"
        style={{ background: s.bg, color: s.color }}
      >
        {s.label}
      </span>
    )
  }

  return (
    <div className="flex min-h-screen" style={{ background: '#FAF6EF' }}>
      {/* Desktop Sidebar */}
      <aside
        className="hidden lg:flex flex-col w-60 fixed top-0 left-0 h-full z-30"
        style={{ background: '#1C1610', borderRight: '1px solid rgba(201,168,76,0.15)' }}
      >
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-40 flex">
          <div className="w-60 flex flex-col h-full" style={{ background: '#1C1610' }}>
            <SidebarContent />
          </div>
          <div className="flex-1 bg-black/50" onClick={() => setSidebarOpen(false)} />
        </div>
      )}

      <main className="flex-1 lg:ml-60">
        {/* Top Bar */}
        <div
          className="sticky top-0 z-20 flex items-center justify-between px-6 py-4 border-b"
          style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}
        >
          <div className="flex items-center gap-4">
            <button className="lg:hidden p-1" onClick={() => setSidebarOpen(true)}><Menu size={20} style={{ color: '#2C2C2C' }} /></button>
            <h1 className="text-lg" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>
              {navItems.find(n => n.id === activeTab)?.label}
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <button className="relative p-2" aria-label="Notifications">
              <Bell size={18} style={{ color: '#7A7068' }} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full text-[0.4rem] flex items-center justify-center" style={{ background: '#C9A84C', color: '#fff' }}>2</span>
            </button>
            <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs" style={{ background: 'linear-gradient(135deg, #9B7A2F, #C9A84C)', color: '#FFFDF7', fontFamily: 'var(--font-jost)' }}>A</div>
          </div>
        </div>

        <div className="p-6 md:p-8">

          {/* DASHBOARD */}
          {activeTab === 'dashboard' && (
            <div className="space-y-8">
              {/* Stats */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { icon: Calendar, label: 'Active Bookings', value: '2', sub: '2025 season', color: '#C9A84C' },
                  { icon: DollarSign, label: 'Revenue (YTD)', value: '$124K', sub: '+18% vs last year', color: '#9B7A2F' },
                  { icon: Users, label: 'New Inquiries', value: '4', sub: 'This month', color: '#E8C4C4' },
                  { icon: Star, label: 'Avg Rating', value: '4.9', sub: 'From 12 reviews', color: '#E2C97E' },
                ].map((stat) => (
                  <div key={stat.label} className="p-5 border" style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}>
                    <div className="flex items-start justify-between mb-3">
                      <stat.icon size={18} style={{ color: stat.color }} />
                      <TrendingUp size={12} style={{ color: '#C9A84C', opacity: 0.7 }} />
                    </div>
                    <div className="text-2xl mb-1" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>{stat.value}</div>
                    <div className="text-[0.55rem] tracking-[0.2em] uppercase" style={{ color: '#B5AFA8' }}>{stat.label}</div>
                    <div className="text-[0.65rem] mt-1" style={{ color: stat.color, fontFamily: 'var(--font-jost)', fontWeight: 300 }}>{stat.sub}</div>
                  </div>
                ))}
              </div>

              {/* Pending Inquiries */}
              {inquiries.filter(i => !approved.includes(i.id) && !rejected.includes(i.id)).length > 0 && (
                <div className="border" style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}>
                  <div className="flex items-center gap-3 px-6 py-4 border-b" style={{ borderColor: '#E2D9CC' }}>
                    <AlertCircle size={15} style={{ color: '#C9A84C' }} />
                    <h3 className="text-base" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>Pending Inquiries</h3>
                    <span className="ml-auto text-xs px-2 py-0.5" style={{ background: '#F5E6C8', color: '#9B7A2F' }}>
                      {inquiries.filter(i => !approved.includes(i.id) && !rejected.includes(i.id)).length} new
                    </span>
                  </div>
                  {inquiries.filter(i => !approved.includes(i.id) && !rejected.includes(i.id)).map((inq) => (
                    <div key={inq.id} className="flex flex-wrap items-center gap-4 px-6 py-4 border-b last:border-0" style={{ borderColor: '#E2D9CC' }}>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium mb-0.5" style={{ color: '#2C2C2C', fontFamily: 'var(--font-jost)' }}>{inq.couple}</div>
                        <div className="text-xs" style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>
                          {inq.service} · {inq.date} · Budget: {inq.budget}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setApproved(p => [...p, inq.id])}
                          className="flex items-center gap-1.5 px-3 py-1.5 text-xs border transition-colors hover:border-[#C9A84C] hover:text-[#C9A84C]"
                          style={{ borderColor: '#E2D9CC', color: '#7A7068' }}
                        >
                          <Check size={11} /> Approve
                        </button>
                        <button
                          onClick={() => setRejected(p => [...p, inq.id])}
                          className="flex items-center gap-1.5 px-3 py-1.5 text-xs border transition-colors hover:border-red-300 hover:text-red-400"
                          style={{ borderColor: '#E2D9CC', color: '#7A7068' }}
                        >
                          <X size={11} /> Decline
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Recent Bookings Preview */}
              <div className="border" style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}>
                <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: '#E2D9CC' }}>
                  <h3 className="text-base" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>Upcoming Weddings</h3>
                  <button onClick={() => setActiveTab('bookings')} className="text-xs flex items-center gap-1" style={{ color: '#C9A84C' }}>
                    View All <ChevronRight size={12} />
                  </button>
                </div>
                {bookings.filter(b => b.status === 'active').map((b, i) => (
                  <div key={i} className="flex flex-wrap items-center gap-4 px-6 py-4 border-b last:border-0" style={{ borderColor: '#E2D9CC' }}>
                    <div className="flex-1">
                      <div className="text-sm font-medium" style={{ color: '#2C2C2C', fontFamily: 'var(--font-jost)' }}>{b.couple}</div>
                      <div className="text-xs mt-0.5" style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>{b.date} · {b.venue}</div>
                    </div>
                    {statusBadge(b.status)}
                    <span className="text-xs" style={{ color: '#B5AFA8' }}>Planner: {b.planner}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* BOOKINGS */}
          {activeTab === 'bookings' && (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse" style={{ background: '#FFFDF7', border: '1px solid #E2D9CC' }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid #E2D9CC', background: '#FAF6EF' }}>
                    {['Couple', 'Wedding Date', 'Service', 'Venue', 'Budget', 'Planner', 'Status'].map((h) => (
                      <th key={h} className="text-left px-5 py-3 text-[0.6rem] tracking-[0.25em] uppercase" style={{ color: '#C9A84C', fontFamily: 'var(--font-jost)', fontWeight: 400 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {bookings.map((b, i) => (
                    <tr key={i} className="transition-colors hover:bg-[#FAF6EF]" style={{ borderBottom: '1px solid #E2D9CC' }}>
                      <td className="px-5 py-4 text-sm font-medium" style={{ color: '#2C2C2C', fontFamily: 'var(--font-jost)' }}>{b.couple}</td>
                      <td className="px-5 py-4 text-sm" style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>{b.date}</td>
                      <td className="px-5 py-4 text-xs" style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>{b.service}</td>
                      <td className="px-5 py-4 text-xs" style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>{b.venue}</td>
                      <td className="px-5 py-4 text-xs" style={{ color: '#C9A84C', fontFamily: 'var(--font-jost)' }}>{b.budget}</td>
                      <td className="px-5 py-4 text-xs" style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>{b.planner}</td>
                      <td className="px-5 py-4">{statusBadge(b.status)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* VENDORS */}
          {activeTab === 'vendors' && (
            <div className="space-y-4">
              {vendors.map((v, i) => (
                <div
                  key={i}
                  className="flex flex-wrap items-center gap-4 p-5 border"
                  style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}
                >
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-xs shrink-0"
                    style={{ background: '#F5E6C8', color: '#9B7A2F', fontFamily: 'var(--font-jost)' }}
                  >
                    {v.name.split(' ').map(w => w[0]).join('').slice(0, 2)}
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-medium" style={{ color: '#2C2C2C', fontFamily: 'var(--font-jost)' }}>{v.name}</div>
                    <div className="text-xs mt-0.5" style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>{v.category} · {v.contact}</div>
                  </div>
                  <div className="flex items-center gap-1">
                    {Array.from({ length: v.rating }).map((_, s) => (
                      <Star key={s} size={11} fill="#C9A84C" color="#C9A84C" />
                    ))}
                  </div>
                  <span className="text-xs" style={{ color: '#B5AFA8' }}>{v.weddings} weddings</span>
                  <span
                    className="text-[0.55rem] tracking-[0.15em] uppercase px-2 py-0.5"
                    style={{
                      background: v.status === 'preferred' ? 'rgba(201,168,76,0.15)' : 'rgba(232,196,196,0.3)',
                      color: v.status === 'preferred' ? '#9B7A2F' : '#8B5050',
                    }}
                  >
                    {v.status}
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* ANALYTICS */}
          {activeTab === 'analytics' && (
            <div className="space-y-8 max-w-3xl">
              <div className="grid grid-cols-2 gap-6">
                {[
                  { label: '2025 Revenue Target', current: 124000, target: 200000 },
                  { label: 'Bookings Target', current: 6, target: 10 },
                ].map((item) => (
                  <div key={item.label} className="p-6 border" style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}>
                    <div className="text-[0.6rem] tracking-[0.25em] uppercase mb-3" style={{ color: '#C9A84C' }}>{item.label}</div>
                    <div className="text-3xl mb-3" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>
                      {typeof item.current === 'number' && item.current > 1000
                        ? `$${(item.current / 1000).toFixed(0)}K`
                        : item.current}
                      <span className="text-lg" style={{ color: '#B5AFA8', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>
                        {' '}/ {typeof item.target === 'number' && item.target > 1000 ? `$${item.target / 1000}K` : item.target}
                      </span>
                    </div>
                    <div className="h-2 rounded-full overflow-hidden" style={{ background: '#E2D9CC' }}>
                      <div
                        className="h-full"
                        style={{
                          width: `${Math.round((item.current / item.target) * 100)}%`,
                          background: 'linear-gradient(to right, #9B7A2F, #C9A84C)',
                        }}
                      />
                    </div>
                    <div className="text-xs mt-2" style={{ color: '#B5AFA8', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>
                      {Math.round((item.current / item.target) * 100)}% of target
                    </div>
                  </div>
                ))}
              </div>

              <div className="border" style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}>
                <div className="px-6 py-4 border-b" style={{ borderColor: '#E2D9CC' }}>
                  <h3 className="text-base" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>Bookings by Service</h3>
                </div>
                {[
                  { label: 'Full Wedding Planning', count: 3, color: '#C9A84C' },
                  { label: 'Partial Planning', count: 1, color: '#E2C97E' },
                  { label: 'Day-of Coordination', count: 1, color: '#E8C4C4' },
                  { label: 'Destination Weddings', count: 1, color: '#9B7A2F' },
                ].map((item) => (
                  <div key={item.label} className="px-6 py-4 border-b last:border-0" style={{ borderColor: '#E2D9CC' }}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm" style={{ color: '#2C2C2C', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>{item.label}</span>
                      <span className="text-sm" style={{ color: item.color, fontFamily: 'var(--font-playfair)' }}>{item.count}</span>
                    </div>
                    <div className="h-1.5 rounded-full overflow-hidden" style={{ background: '#E2D9CC' }}>
                      <div className="h-full rounded-full" style={{ width: `${(item.count / 6) * 100}%`, background: item.color }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* CLIENTS */}
          {activeTab === 'clients' && (
            <div className="space-y-3 max-w-3xl">
              {bookings.map((b, i) => (
                <div key={i} className="flex flex-wrap items-center gap-4 p-5 border" style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}>
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-xs shrink-0"
                    style={{ background: 'linear-gradient(135deg, #9B7A2F, #C9A84C)', color: '#FFFDF7', fontFamily: 'var(--font-jost)' }}
                  >
                    {b.couple.split(' ')[0][0]}
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-medium" style={{ color: '#2C2C2C', fontFamily: 'var(--font-jost)' }}>{b.couple}</div>
                    <div className="text-xs mt-0.5" style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>
                      {b.service} · {b.date}
                    </div>
                  </div>
                  {statusBadge(b.status)}
                  <button className="text-xs flex items-center gap-1" style={{ color: '#C9A84C' }}>
                    View <ChevronRight size={12} />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* SETTINGS */}
          {activeTab === 'settings' && (
            <div className="max-w-xl space-y-6">
              {['Company Information', 'Team Management', 'Notification Preferences', 'Pricing & Packages', 'Content Management'].map((section) => (
                <div
                  key={section}
                  className="flex items-center justify-between p-5 border cursor-pointer hover:bg-[#FAF6EF] transition-colors"
                  style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}
                >
                  <div className="text-sm" style={{ color: '#2C2C2C', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>{section}</div>
                  <ChevronRight size={14} style={{ color: '#B5AFA8' }} />
                </div>
              ))}
            </div>
          )}

        </div>
      </main>
    </div>
  )
}
