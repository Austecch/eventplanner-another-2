'use client'

import { useState } from 'react'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import { Check, ChevronRight, Calendar, User, Heart, DollarSign } from 'lucide-react'

type FormData = {
  // Step 1
  firstName: string
  lastName: string
  email: string
  phone: string
  partnerFirstName: string
  partnerLastName: string
  // Step 2
  weddingDate: string
  guestCount: string
  venue: string
  service: string
  style: string
  // Step 3
  budget: string
  heardFrom: string
  additionalInfo: string
}

const initialData: FormData = {
  firstName: '', lastName: '', email: '', phone: '',
  partnerFirstName: '', partnerLastName: '',
  weddingDate: '', guestCount: '', venue: '', service: '', style: '',
  budget: '', heardFrom: '', additionalInfo: '',
}

const steps = [
  { id: 1, label: 'Your Info', icon: User },
  { id: 2, label: 'Wedding Details', icon: Heart },
  { id: 3, label: 'Budget & Notes', icon: DollarSign },
]

export default function BookingPage() {
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState<FormData>(initialData)
  const [submitted, setSubmitted] = useState(false)

  const update = (field: keyof FormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = () => {
    setSubmitted(true)
  }

  const inputClass = `w-full border px-4 py-3.5 text-sm focus:outline-none transition-colors duration-300 focus:border-[#C9A84C]`
  const inputStyle = {
    background: '#FFFDF7',
    borderColor: '#E2D9CC',
    color: '#2C2C2C',
    fontFamily: 'var(--font-jost)',
    fontWeight: 300,
  }
  const labelClass = `block text-[0.6rem] tracking-[0.25em] uppercase mb-2`
  const labelStyle = { color: '#C9A84C', fontFamily: 'var(--font-jost)' }

  return (
    <div>
      <Navbar />

      {/* Hero */}
      <section
        className="relative pt-36 pb-16 px-6"
        style={{ background: '#1C1610' }}
      >
        <img
          src="https://placehold.co/1920x500?text=Luxury+wedding+consultation+session+couple+with+planner+mood+boards+champagne+intimate+editorial"
          alt="Luxury wedding consultation session with couple and planner"
          className="absolute inset-0 w-full h-full object-cover opacity-20"
        />
        <div className="relative z-10 max-w-3xl mx-auto text-center">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
            <span className="text-[0.6rem] tracking-[0.4em] uppercase" style={{ color: '#C9A84C' }}>
              Begin Your Journey
            </span>
            <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
          </div>
          <h1
            className="text-4xl md:text-6xl mb-6"
            style={{ fontFamily: 'var(--font-playfair)', color: '#FFFDF7', lineHeight: '1.1' }}
          >
            Request a<br />
            <em style={{ color: '#C9A84C' }}>Complimentary Consultation</em>
          </h1>
          <p
            className="text-sm max-w-xl mx-auto"
            style={{ color: '#B5AFA8', fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.9' }}
          >
            We accept a limited number of weddings each year to ensure every couple receives
            our full attention and artistry. Complete this form to begin.
          </p>
        </div>
      </section>

      {/* Form Container */}
      <section className="py-20 px-6" style={{ background: '#FAF6EF' }}>
        <div className="max-w-2xl mx-auto">

          {submitted ? (
            /* Success State */
            <div
              className="text-center py-20 px-8"
              style={{ background: '#FFFDF7', border: '1px solid #E2D9CC' }}
            >
              <div
                className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-8"
                style={{ background: 'linear-gradient(135deg, #9B7A2F, #C9A84C, #E2C97E)' }}
              >
                <Check size={32} color="#FFFDF7" strokeWidth={2.5} />
              </div>
              <h2
                className="text-3xl md:text-4xl mb-4"
                style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}
              >
                Your Request Has Been Sent
              </h2>
              <div className="w-12 h-px mx-auto mb-6" style={{ background: '#C9A84C' }} />
              <p
                className="text-sm leading-relaxed mb-8 max-w-sm mx-auto"
                style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.9' }}
              >
                Thank you, <strong>{formData.firstName}</strong>. We are delighted to hear from you.
                Our team will be in touch within 24 hours to schedule your discovery call.
              </p>
              <p
                className="text-[0.6rem] tracking-[0.2em] uppercase mb-8"
                style={{ color: '#C9A84C' }}
              >
                Check your email at {formData.email}
              </p>
              <a href="/" className="btn-outline-gold inline-block">
                Return to Home
              </a>
            </div>
          ) : (
            <>
              {/* Step Indicator */}
              <div className="flex items-center justify-center mb-12">
                {steps.map((s, i) => (
                  <div key={s.id} className="flex items-center">
                    <div className="flex flex-col items-center gap-2">
                      <div
                        className="w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-400"
                        style={{
                          borderColor: step >= s.id ? '#C9A84C' : '#E2D9CC',
                          background: step > s.id ? '#C9A84C' : step === s.id ? 'transparent' : '#FFFDF7',
                        }}
                      >
                        {step > s.id ? (
                          <Check size={14} color="#FFFDF7" />
                        ) : (
                          <s.icon size={14} style={{ color: step === s.id ? '#C9A84C' : '#B5AFA8' }} />
                        )}
                      </div>
                      <span
                        className="text-[0.55rem] tracking-[0.2em] uppercase whitespace-nowrap"
                        style={{ color: step === s.id ? '#C9A84C' : '#B5AFA8', fontFamily: 'var(--font-jost)' }}
                      >
                        {s.label}
                      </span>
                    </div>
                    {i < steps.length - 1 && (
                      <div
                        className="w-16 md:w-24 h-px mx-2 mb-5 transition-all duration-500"
                        style={{ background: step > s.id ? '#C9A84C' : '#E2D9CC' }}
                      />
                    )}
                  </div>
                ))}
              </div>

              <div style={{ background: '#FFFDF7', border: '1px solid #E2D9CC' }} className="p-8 md:p-12">

                {/* Step 1 */}
                {step === 1 && (
                  <div>
                    <h2 className="text-2xl md:text-3xl mb-2" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>
                      Tell Us About Yourselves
                    </h2>
                    <p className="text-sm mb-8" style={{ color: '#B5AFA8', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>
                      A little about the beautiful couple
                    </p>

                    <div className="grid sm:grid-cols-2 gap-5">
                      <div>
                        <label className={labelClass} style={labelStyle}>Your First Name</label>
                        <input className={inputClass} style={inputStyle} value={formData.firstName} onChange={(e) => update('firstName', e.target.value)} placeholder="Sophia" />
                      </div>
                      <div>
                        <label className={labelClass} style={labelStyle}>Your Last Name</label>
                        <input className={inputClass} style={inputStyle} value={formData.lastName} onChange={(e) => update('lastName', e.target.value)} placeholder="Hartley" />
                      </div>
                      <div>
                        <label className={labelClass} style={labelStyle}>Partner&apos;s First Name</label>
                        <input className={inputClass} style={inputStyle} value={formData.partnerFirstName} onChange={(e) => update('partnerFirstName', e.target.value)} placeholder="James" />
                      </div>
                      <div>
                        <label className={labelClass} style={labelStyle}>Partner&apos;s Last Name</label>
                        <input className={inputClass} style={inputStyle} value={formData.partnerLastName} onChange={(e) => update('partnerLastName', e.target.value)} placeholder="Hartley" />
                      </div>
                      <div>
                        <label className={labelClass} style={labelStyle}>Email Address</label>
                        <input type="email" className={inputClass} style={inputStyle} value={formData.email} onChange={(e) => update('email', e.target.value)} placeholder="hello@youremail.com" />
                      </div>
                      <div>
                        <label className={labelClass} style={labelStyle}>Phone Number</label>
                        <input type="tel" className={inputClass} style={inputStyle} value={formData.phone} onChange={(e) => update('phone', e.target.value)} placeholder="+1 (908) 555-0100" />
                      </div>
                    </div>
                  </div>
                )}

                {/* Step 2 */}
                {step === 2 && (
                  <div>
                    <h2 className="text-2xl md:text-3xl mb-2" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>
                      Your Wedding Details
                    </h2>
                    <p className="text-sm mb-8" style={{ color: '#B5AFA8', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>
                      Help us understand your vision
                    </p>

                    <div className="grid sm:grid-cols-2 gap-5">
                      <div>
                        <label className={labelClass} style={labelStyle}>Wedding Date</label>
                        <input type="date" className={inputClass} style={inputStyle} value={formData.weddingDate} onChange={(e) => update('weddingDate', e.target.value)} />
                      </div>
                      <div>
                        <label className={labelClass} style={labelStyle}>Expected Guest Count</label>
                        <select className={inputClass} style={inputStyle} value={formData.guestCount} onChange={(e) => update('guestCount', e.target.value)}>
                          <option value="">Select range</option>
                          <option>Under 50</option>
                          <option>50 – 100</option>
                          <option>100 – 150</option>
                          <option>150 – 250</option>
                          <option>250+</option>
                        </select>
                      </div>
                      <div className="sm:col-span-2">
                        <label className={labelClass} style={labelStyle}>Venue (if known)</label>
                        <input className={inputClass} style={inputStyle} value={formData.venue} onChange={(e) => update('venue', e.target.value)} placeholder="e.g. Park Chateau Estate, or still searching" />
                      </div>
                      <div>
                        <label className={labelClass} style={labelStyle}>Service Interested In</label>
                        <select className={inputClass} style={inputStyle} value={formData.service} onChange={(e) => update('service', e.target.value)}>
                          <option value="">Select service</option>
                          <option>Full Wedding Planning</option>
                          <option>Partial Planning</option>
                          <option>Day-of Coordination</option>
                          <option>Destination Wedding</option>
                          <option>Not Sure Yet</option>
                        </select>
                      </div>
                      <div>
                        <label className={labelClass} style={labelStyle}>Wedding Style</label>
                        <select className={inputClass} style={inputStyle} value={formData.style} onChange={(e) => update('style', e.target.value)}>
                          <option value="">Select style</option>
                          <option>Garden Romance</option>
                          <option>Black Tie Elegance</option>
                          <option>Rustic Luxe</option>
                          <option>Modern Minimalist</option>
                          <option>Destination / Tropical</option>
                          <option>South Asian Fusion</option>
                          <option>Vintage Romantic</option>
                          <option>Still Deciding</option>
                        </select>
                      </div>
                    </div>
                  </div>
                )}

                {/* Step 3 */}
                {step === 3 && (
                  <div>
                    <h2 className="text-2xl md:text-3xl mb-2" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>
                      Budget &amp; Final Notes
                    </h2>
                    <p className="text-sm mb-8" style={{ color: '#B5AFA8', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>
                      Almost there — a few final details
                    </p>

                    <div className="space-y-5">
                      <div>
                        <label className={labelClass} style={labelStyle}>Estimated Wedding Budget</label>
                        <select className={inputClass} style={inputStyle} value={formData.budget} onChange={(e) => update('budget', e.target.value)}>
                          <option value="">Select range</option>
                          <option>Under $25,000</option>
                          <option>$25,000 – $50,000</option>
                          <option>$50,000 – $100,000</option>
                          <option>$100,000 – $150,000</option>
                          <option>$150,000+</option>
                          <option>Prefer not to say</option>
                        </select>
                      </div>
                      <div>
                        <label className={labelClass} style={labelStyle}>How Did You Hear About Us?</label>
                        <select className={inputClass} style={inputStyle} value={formData.heardFrom} onChange={(e) => update('heardFrom', e.target.value)}>
                          <option value="">Select one</option>
                          <option>Instagram</option>
                          <option>Pinterest</option>
                          <option>The Knot</option>
                          <option>Google Search</option>
                          <option>Friend / Family Referral</option>
                          <option>Past Client Referral</option>
                          <option>Wedding Publication</option>
                          <option>Other</option>
                        </select>
                      </div>
                      <div>
                        <label className={labelClass} style={labelStyle}>Anything Else We Should Know?</label>
                        <textarea
                          className={inputClass}
                          style={{ ...inputStyle, resize: 'none' }}
                          rows={5}
                          value={formData.additionalInfo}
                          onChange={(e) => update('additionalInfo', e.target.value)}
                          placeholder="Share your vision, any challenges, or anything that will help us understand your dream wedding..."
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Navigation Buttons */}
                <div className="flex items-center justify-between mt-10 pt-8 border-t" style={{ borderColor: '#E2D9CC' }}>
                  {step > 1 ? (
                    <button
                      onClick={() => setStep((s) => s - 1)}
                      className="btn-outline-gold inline-flex items-center gap-2 text-xs"
                    >
                      Back
                    </button>
                  ) : (
                    <div />
                  )}

                  {step < 3 ? (
                    <button
                      onClick={() => setStep((s) => s + 1)}
                      className="btn-gold inline-flex items-center gap-2"
                    >
                      Continue
                      <ChevronRight size={14} />
                    </button>
                  ) : (
                    <button
                      onClick={handleSubmit}
                      className="btn-gold inline-flex items-center gap-2"
                    >
                      Submit Request
                      <Check size={14} />
                    </button>
                  )}
                </div>
              </div>

              <p
                className="text-center mt-6 text-[0.6rem] tracking-[0.15em] uppercase"
                style={{ color: '#B5AFA8', fontFamily: 'var(--font-jost)' }}
              >
                We respond to all inquiries within 24 hours
              </p>
            </>
          )}
        </div>
      </section>

      <Footer />
    </div>
  )
}
