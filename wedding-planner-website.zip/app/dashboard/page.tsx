'use client'

import { useState } from 'react'
import Link from 'next/link'
import {
  LayoutDashboard, CheckSquare, DollarSign, Calendar,
  FileText, MessageCircle, LogOut, Upload, ChevronRight,
  Bell, Menu, X, CheckCircle2, Clock, Circle
} from 'lucide-react'

const navItems = [
  { icon: LayoutDashboard, label: 'Overview', id: 'overview' },
  { icon: CheckSquare, label: 'Progress', id: 'progress' },
  { icon: DollarSign, label: 'Budget', id: 'budget' },
  { icon: Calendar, label: 'Timeline', id: 'timeline' },
  { icon: FileText, label: 'Documents', id: 'documents' },
  { icon: MessageCircle, label: 'Messages', id: 'messages' },
]

const progressItems = [
  { label: 'Signed Contract', done: true },
  { label: 'Paid Retainer', done: true },
  { label: 'Venue Confirmed', done: true },
  { label: 'Catering Booked', done: true },
  { label: 'Photography Booked', done: true },
  { label: 'Floral Design Approved', done: false, active: true },
  { label: 'Invitations Sent', done: false },
  { label: 'Guest RSVP Deadline', done: false },
  { label: 'Final Payments Due', done: false },
  { label: 'Wedding Day', done: false },
]

const budgetItems = [
  { category: 'Venue', budgeted: 18000, spent: 18000, color: '#C9A84C' },
  { category: 'Catering', budgeted: 22000, spent: 19500, color: '#E8C4C4' },
  { category: 'Photography', budgeted: 6000, spent: 6000, color: '#9B7A2F' },
  { category: 'Florals & Decor', budgeted: 12000, spent: 4200, color: '#E2C97E' },
  { category: 'Music / DJ', budgeted: 4000, spent: 0, color: '#D4A5A5' },
  { category: 'Hair & Makeup', budgeted: 2500, spent: 800, color: '#B5AFA8' },
  { category: 'Wedding Attire', budgeted: 8000, spent: 5400, color: '#7A7068' },
  { category: 'Stationery', budgeted: 1500, spent: 600, color: '#C9A84C' },
]

const timelineEvents = [
  { date: 'Jan 2025', label: 'Signed with Veil & Bloom', done: true },
  { date: 'Feb 2025', label: 'Vision Meeting & Mood Board', done: true },
  { date: 'Mar 2025', label: 'Venue Tour & Confirmation', done: true },
  { date: 'Apr 2025', label: 'Vendor Team Finalized', done: true },
  { date: 'May 2025', label: 'Design Review & Approval', done: false, active: true },
  { date: 'Jun 2025', label: 'Invitations Mail Out', done: false },
  { date: 'Aug 2025', label: 'RSVP Deadline', done: false },
  { date: 'Sep 2025', label: 'Final Tasting & Walkthrough', done: false },
  { date: 'Oct 4, 2025', label: 'Wedding Day', done: false, special: true },
]

const messages = [
  { from: 'Isabelle Laurent', role: 'Lead Planner', time: '2h ago', preview: 'Hi Sophie! Just confirming the floral design meeting for Thursday at 2pm. Can\'t wait to show you the final mockups!', unread: true },
  { from: 'Charlotte Vance', role: 'Creative Director', time: '1d ago', preview: 'The mood board updates are ready for your review. I\'ve added three new tablescape concepts I think you\'ll adore.', unread: false },
  { from: 'Naomi Rivers', role: 'Coordinator', time: '2d ago', preview: 'Vendor timeline has been updated. All confirmations are in for October. Everything is on track!', unread: false },
]

const documents = [
  { name: 'Service Contract.pdf', date: 'Jan 12, 2025', size: '240 KB' },
  { name: 'Venue Contract - Park Chateau.pdf', date: 'Mar 3, 2025', size: '1.2 MB' },
  { name: 'Design Mood Board v2.pdf', date: 'Apr 18, 2025', size: '8.4 MB' },
  { name: 'Vendor Contact Sheet.xlsx', date: 'Apr 20, 2025', size: '44 KB' },
  { name: 'Wedding Day Timeline Draft.pdf', date: 'May 1, 2025', size: '320 KB' },
]

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState('overview')
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const totalBudgeted = budgetItems.reduce((s, i) => s + i.budgeted, 0)
  const totalSpent = budgetItems.reduce((s, i) => s + i.spent, 0)
  const doneCount = progressItems.filter((p) => p.done).length
  const progressPct = Math.round((doneCount / progressItems.length) * 100)

  const SidebarContent = () => (
    <>
      <div className="px-6 py-8 border-b" style={{ borderColor: 'rgba(201,168,76,0.2)' }}>
        <Link href="/" className="block">
          <div className="text-xl tracking-wider mb-1" style={{ fontFamily: 'var(--font-playfair)', color: '#F5E6C8' }}>
            Veil &amp; Bloom
          </div>
          <div className="text-[0.55rem] tracking-[0.3em] uppercase" style={{ color: '#C9A84C' }}>
            Client Portal
          </div>
        </Link>
      </div>

      {/* Couple Info */}
      <div className="px-6 py-6 border-b" style={{ borderColor: 'rgba(201,168,76,0.15)' }}>
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium"
            style={{ background: 'linear-gradient(135deg, #9B7A2F, #C9A84C)', color: '#FFFDF7', fontFamily: 'var(--font-jost)' }}
          >
            S&amp;J
          </div>
          <div>
            <div className="text-sm" style={{ color: '#F5E6C8', fontFamily: 'var(--font-jost)', fontWeight: 400 }}>
              Sophia &amp; James
            </div>
            <div className="text-[0.6rem] tracking-wider" style={{ color: '#C9A84C' }}>
              Oct 4, 2025
            </div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="px-3 py-6 flex-1">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => { setActiveTab(item.id); setSidebarOpen(false) }}
            className="w-full flex items-center gap-3 px-4 py-3 mb-1 text-left transition-all duration-300"
            style={{
              background: activeTab === item.id ? 'rgba(201,168,76,0.15)' : 'transparent',
              borderLeft: activeTab === item.id ? '2px solid #C9A84C' : '2px solid transparent',
              color: activeTab === item.id ? '#C9A84C' : '#7A7068',
            }}
          >
            <item.icon size={15} />
            <span className="text-xs tracking-[0.1em]" style={{ fontFamily: 'var(--font-jost)', fontWeight: 300 }}>
              {item.label}
            </span>
          </button>
        ))}
      </nav>

      <div className="px-6 pb-8">
        <Link href="/" className="flex items-center gap-3 text-xs transition-colors hover:text-[#C9A84C]"
          style={{ color: '#5C5248', fontFamily: 'var(--font-jost)' }}>
          <LogOut size={13} />
          Sign Out
        </Link>
      </div>
    </>
  )

  return (
    <div className="flex min-h-screen" style={{ background: '#FAF6EF' }}>
      {/* Desktop Sidebar */}
      <aside
        className="hidden lg:flex flex-col w-60 fixed top-0 left-0 h-full z-30"
        style={{ background: '#1C1610', borderRight: '1px solid rgba(201,168,76,0.15)' }}
      >
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-40 flex">
          <div className="w-60 flex flex-col h-full" style={{ background: '#1C1610' }}>
            <SidebarContent />
          </div>
          <div className="flex-1 bg-black/50" onClick={() => setSidebarOpen(false)} />
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 lg:ml-60">
        {/* Top Bar */}
        <div
          className="sticky top-0 z-20 flex items-center justify-between px-6 py-4 border-b"
          style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}
        >
          <div className="flex items-center gap-4">
            <button
              className="lg:hidden p-1"
              onClick={() => setSidebarOpen(true)}
              aria-label="Open menu"
            >
              <Menu size={20} style={{ color: '#2C2C2C' }} />
            </button>
            <h1
              className="text-lg"
              style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}
            >
              {navItems.find((n) => n.id === activeTab)?.label}
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <button className="relative p-2" aria-label="Notifications">
              <Bell size={18} style={{ color: '#7A7068' }} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full" style={{ background: '#C9A84C' }} />
            </button>
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center text-xs"
              style={{ background: 'linear-gradient(135deg, #9B7A2F, #C9A84C)', color: '#FFFDF7', fontFamily: 'var(--font-jost)' }}
            >
              S
            </div>
          </div>
        </div>

        <div className="p-6 md:p-8">

          {/* OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-8">
              {/* Welcome Banner */}
              <div
                className="relative overflow-hidden p-8"
                style={{ background: '#1C1610' }}
              >
                <img
                  src="https://placehold.co/1200x200?text=Elegant+blurred+wedding+florals+champagne+roses+soft+bokeh+dark+moody+background"
                  alt="Elegant blurred wedding florals background"
                  className="absolute inset-0 w-full h-full object-cover opacity-20"
                />
                <div className="relative z-10">
                  <p className="text-[0.6rem] tracking-[0.3em] uppercase mb-2" style={{ color: '#C9A84C' }}>
                    Welcome Back
                  </p>
                  <h2 className="text-2xl md:text-3xl mb-2" style={{ fontFamily: 'var(--font-playfair)', color: '#F5E6C8' }}>
                    Sophia &amp; James
                  </h2>
                  <p className="text-sm" style={{ color: '#B5AFA8', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>
                    Your wedding is in <strong style={{ color: '#E2C97E' }}>127 days</strong>. Everything is on track.
                  </p>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: 'Days Until Wedding', value: '127', sub: 'October 4, 2025' },
                  { label: 'Planning Progress', value: `${progressPct}%`, sub: `${doneCount}/${progressItems.length} tasks` },
                  { label: 'Budget Spent', value: `$${totalSpent.toLocaleString()}`, sub: `of $${totalBudgeted.toLocaleString()}` },
                  { label: 'Vendors Confirmed', value: '8/11', sub: '3 pending confirmation' },
                ].map((stat) => (
                  <div
                    key={stat.label}
                    className="p-5 border"
                    style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}
                  >
                    <div className="text-[0.55rem] tracking-[0.25em] uppercase mb-1" style={{ color: '#C9A84C' }}>{stat.label}</div>
                    <div className="text-2xl mb-1" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>{stat.value}</div>
                    <div className="text-xs" style={{ color: '#B5AFA8', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>{stat.sub}</div>
                  </div>
                ))}
              </div>

              {/* Recent Messages */}
              <div className="border" style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}>
                <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: '#E2D9CC' }}>
                  <h3 className="text-base" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>Recent Messages</h3>
                  <button onClick={() => setActiveTab('messages')} className="text-xs flex items-center gap-1" style={{ color: '#C9A84C' }}>
                    View All <ChevronRight size={12} />
                  </button>
                </div>
                {messages.slice(0, 2).map((msg, i) => (
                  <div key={i} className={`px-6 py-4 flex gap-4 border-b last:border-0 ${msg.unread ? '' : 'opacity-70'}`} style={{ borderColor: '#E2D9CC' }}>
                    <div className="w-9 h-9 rounded-full shrink-0 flex items-center justify-center text-xs" style={{ background: '#F5E6C8', color: '#9B7A2F', fontFamily: 'var(--font-jost)' }}>
                      {msg.from.split(' ').map(w => w[0]).join('')}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="text-xs font-medium" style={{ color: '#2C2C2C', fontFamily: 'var(--font-jost)' }}>{msg.from}</span>
                        {msg.unread && <span className="w-1.5 h-1.5 rounded-full" style={{ background: '#C9A84C' }} />}
                        <span className="text-xs ml-auto shrink-0" style={{ color: '#B5AFA8' }}>{msg.time}</span>
                      </div>
                      <p className="text-xs truncate" style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>{msg.preview}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* PROGRESS */}
          {activeTab === 'progress' && (
            <div className="max-w-2xl space-y-6">
              <div
                className="p-6 border mb-6"
                style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm" style={{ color: '#2C2C2C', fontFamily: 'var(--font-jost)' }}>Overall Progress</span>
                  <span className="text-sm" style={{ color: '#C9A84C', fontFamily: 'var(--font-playfair)' }}>{progressPct}%</span>
                </div>
                <div className="h-2 rounded-full overflow-hidden" style={{ background: '#E2D9CC' }}>
                  <div
                    className="h-full transition-all duration-700"
                    style={{ width: `${progressPct}%`, background: 'linear-gradient(to right, #9B7A2F, #C9A84C, #E2C97E)' }}
                  />
                </div>
              </div>
              {progressItems.map((item, i) => (
                <div
                  key={i}
                  className="flex items-center gap-4 p-5 border"
                  style={{
                    background: item.active ? '#FFFCF3' : '#FFFDF7',
                    borderColor: item.active ? '#C9A84C' : '#E2D9CC',
                  }}
                >
                  {item.done ? (
                    <CheckCircle2 size={20} style={{ color: '#C9A84C', shrink: 0 }} className="shrink-0" />
                  ) : item.active ? (
                    <Clock size={20} style={{ color: '#C9A84C' }} className="shrink-0 animate-pulse" />
                  ) : (
                    <Circle size={20} style={{ color: '#E2D9CC' }} className="shrink-0" />
                  )}
                  <span
                    className="text-sm"
                    style={{
                      color: item.done ? '#B5AFA8' : '#2C2C2C',
                      fontFamily: 'var(--font-jost)',
                      fontWeight: 300,
                      textDecoration: item.done ? 'line-through' : 'none',
                    }}
                  >
                    {item.label}
                  </span>
                  {item.active && (
                    <span
                      className="ml-auto text-[0.55rem] tracking-[0.2em] uppercase px-2 py-0.5"
                      style={{ background: '#F5E6C8', color: '#9B7A2F' }}
                    >
                      In Progress
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* BUDGET */}
          {activeTab === 'budget' && (
            <div className="space-y-6 max-w-3xl">
              {/* Summary */}
              <div className="grid grid-cols-3 gap-4">
                {[
                  { label: 'Total Budget', value: `$${totalBudgeted.toLocaleString()}` },
                  { label: 'Spent So Far', value: `$${totalSpent.toLocaleString()}` },
                  { label: 'Remaining', value: `$${(totalBudgeted - totalSpent).toLocaleString()}` },
                ].map((s) => (
                  <div key={s.label} className="p-5 border text-center" style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}>
                    <div className="text-[0.55rem] tracking-[0.25em] uppercase mb-1" style={{ color: '#C9A84C' }}>{s.label}</div>
                    <div className="text-xl" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>{s.value}</div>
                  </div>
                ))}
              </div>
              {/* Items */}
              <div className="border" style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}>
                <div className="px-6 py-4 border-b" style={{ borderColor: '#E2D9CC' }}>
                  <h3 className="text-base" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>Budget Breakdown</h3>
                </div>
                {budgetItems.map((item) => {
                  const pct = Math.round((item.spent / item.budgeted) * 100)
                  return (
                    <div key={item.category} className="px-6 py-4 border-b last:border-0" style={{ borderColor: '#E2D9CC' }}>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm" style={{ color: '#2C2C2C', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>{item.category}</span>
                        <div className="flex items-center gap-3 text-xs" style={{ fontFamily: 'var(--font-jost)' }}>
                          <span style={{ color: '#C9A84C' }}>${item.spent.toLocaleString()}</span>
                          <span style={{ color: '#B5AFA8' }}>/ ${item.budgeted.toLocaleString()}</span>
                        </div>
                      </div>
                      <div className="h-1.5 rounded-full overflow-hidden" style={{ background: '#E2D9CC' }}>
                        <div
                          className="h-full rounded-full transition-all duration-700"
                          style={{ width: `${pct}%`, background: item.color }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {/* TIMELINE */}
          {activeTab === 'timeline' && (
            <div className="max-w-xl">
              <div className="relative pl-8 border-l-2" style={{ borderColor: '#E2D9CC' }}>
                {timelineEvents.map((event, i) => (
                  <div
                    key={i}
                    className="relative mb-8"
                  >
                    {/* Dot */}
                    <div
                      className="absolute -left-[2.35rem] top-0 w-4 h-4 rounded-full border-2 flex items-center justify-center"
                      style={{
                        borderColor: event.done || event.active ? '#C9A84C' : '#E2D9CC',
                        background: event.done ? '#C9A84C' : event.special ? '#1C1610' : '#FFFDF7',
                      }}
                    >
                      {event.done && <Check size={8} color="#FFFDF7" />}
                    </div>

                    <div
                      className="p-5 border"
                      style={{
                        background: event.active ? '#FFFCF3' : event.special ? '#1C1610' : '#FFFDF7',
                        borderColor: event.active || event.special ? '#C9A84C' : '#E2D9CC',
                      }}
                    >
                      <div
                        className="text-[0.6rem] tracking-[0.25em] uppercase mb-1"
                        style={{ color: '#C9A84C' }}
                      >
                        {event.date}
                      </div>
                      <div
                        className={`text-sm ${event.special ? 'text-lg' : ''}`}
                        style={{
                          fontFamily: event.special ? 'var(--font-playfair)' : 'var(--font-jost)',
                          color: event.special ? '#F5E6C8' : event.done ? '#B5AFA8' : '#2C2C2C',
                          fontWeight: 300,
                        }}
                      >
                        {event.label}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* DOCUMENTS */}
          {activeTab === 'documents' && (
            <div className="max-w-2xl space-y-4">
              <div
                className="border-2 border-dashed p-8 text-center cursor-pointer transition-colors duration-300 hover:border-[#C9A84C]"
                style={{ borderColor: '#E2D9CC', background: '#FFFDF7' }}
              >
                <Upload size={24} className="mx-auto mb-3" style={{ color: '#C9A84C' }} />
                <p className="text-sm" style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>
                  Drop files here or click to upload
                </p>
                <p className="text-xs mt-1" style={{ color: '#B5AFA8' }}>PDF, JPG, PNG, XLSX up to 20MB</p>
              </div>

              <div className="border" style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}>
                <div className="px-6 py-4 border-b" style={{ borderColor: '#E2D9CC' }}>
                  <h3 className="text-base" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>Shared Documents</h3>
                </div>
                {documents.map((doc, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-4 px-6 py-4 border-b last:border-0 cursor-pointer hover:bg-[#FAF6EF] transition-colors"
                    style={{ borderColor: '#E2D9CC' }}
                  >
                    <FileText size={16} style={{ color: '#C9A84C', flexShrink: 0 }} />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm truncate" style={{ color: '#2C2C2C', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>{doc.name}</div>
                      <div className="text-xs" style={{ color: '#B5AFA8' }}>{doc.date} · {doc.size}</div>
                    </div>
                    <ChevronRight size={14} style={{ color: '#B5AFA8', flexShrink: 0 }} />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* MESSAGES */}
          {activeTab === 'messages' && (
            <div className="max-w-2xl">
              <div className="border" style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}>
                {messages.map((msg, i) => (
                  <div
                    key={i}
                    className="flex gap-4 p-6 border-b last:border-0 cursor-pointer hover:bg-[#FAF6EF] transition-colors"
                    style={{ borderColor: '#E2D9CC' }}
                  >
                    <div
                      className="w-10 h-10 rounded-full shrink-0 flex items-center justify-center text-xs font-medium"
                      style={{ background: '#F5E6C8', color: '#9B7A2F', fontFamily: 'var(--font-jost)' }}
                    >
                      {msg.from.split(' ').map(w => w[0]).join('')}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-medium" style={{ color: '#2C2C2C', fontFamily: 'var(--font-jost)' }}>{msg.from}</span>
                        <span className="text-[0.55rem] tracking-[0.15em] uppercase" style={{ color: '#C9A84C' }}>{msg.role}</span>
                        {msg.unread && <span className="w-2 h-2 rounded-full shrink-0" style={{ background: '#C9A84C' }} />}
                        <span className="text-xs ml-auto shrink-0" style={{ color: '#B5AFA8' }}>{msg.time}</span>
                      </div>
                      <p className="text-sm" style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.7' }}>
                        {msg.preview}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div
                className="mt-6 p-4 border flex gap-3"
                style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}
              >
                <input
                  className="flex-1 text-sm px-4 py-3 border focus:outline-none focus:border-[#C9A84C] transition-colors"
                  style={{ borderColor: '#E2D9CC', background: '#FAF6EF', color: '#2C2C2C', fontFamily: 'var(--font-jost)', fontWeight: 300 }}
                  placeholder="Send a message to your planning team..."
                />
                <button className="btn-gold px-5 py-3 text-xs">Send</button>
              </div>
            </div>
          )}

        </div>
      </main>
    </div>
  )
}
