'use client'

import { useState, useEffect, useRef } from 'react'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import Link from 'next/link'
import { X, ChevronLeft, ChevronRight } from 'lucide-react'

const allWeddings = [
  {
    id: 1,
    title: 'Sophia & James',
    venue: 'Park Chateau Estate',
    style: 'Garden Romance',
    season: 'Fall',
    image: 'https://placehold.co/800x1000?text=Romantic+outdoor+ceremony+bride+ivory+lace+gown+floral+arch+golden+hour+New+Jersey+garden+estate',
    alt: 'Sophia and James outdoor ceremony with ivory lace gown and floral arch at golden hour in New Jersey',
    tall: true,
  },
  {
    id: 2,
    title: 'Elena & Marcus',
    venue: 'The Grand Ballroom',
    style: 'Black Tie Elegance',
    season: 'Summer',
    image: 'https://placehold.co/800x600?text=Black+tie+ballroom+reception+gold+chandeliers+white+roses+candlelight+Morristown+NJ',
    alt: 'Elena and Marcus black tie ballroom reception with gold chandeliers and white roses',
    tall: false,
  },
  {
    id: 3,
    title: 'Amara & Daniel',
    venue: 'Natirar Mansion',
    style: 'Rustic Luxe',
    season: 'Fall',
    image: 'https://placehold.co/800x800?text=Rustic+luxury+wedding+mansion+grounds+wildflower+meadow+first+dance+amber+twilight+NJ',
    alt: 'Amara and Daniel rustic luxury wedding at Natirar Mansion with wildflower meadow',
    tall: false,
  },
  {
    id: 4,
    title: 'Claire & William',
    venue: 'Liberty House',
    style: 'Modern Minimalist',
    season: 'Spring',
    image: 'https://placehold.co/800x1000?text=Modern+wedding+Jersey+City+Liberty+House+Manhattan+skyline+sleek+white+gold+floral',
    alt: 'Claire and William modern wedding at Liberty House with Manhattan skyline backdrop',
    tall: true,
  },
  {
    id: 5,
    title: 'Priya & Rohan',
    venue: "Nanina's In The Park",
    style: 'South Asian Fusion',
    season: 'Spring',
    image: 'https://placehold.co/800x600?text=South+Asian+fusion+wedding+vibrant+marigold+garlands+mandap+golden+hour+NJ+venue',
    alt: 'Priya and Rohan South Asian fusion wedding with vibrant marigold garlands and ornate mandap',
    tall: false,
  },
  {
    id: 6,
    title: 'Natalie & Ryan',
    venue: 'Crossed Keys Inn',
    style: 'Vintage Romantic',
    season: 'Summer',
    image: 'https://placehold.co/800x1000?text=Vintage+romantic+wedding+historic+inn+NJ+antique+details+soft+candlelight+dusty+rose+palette',
    alt: 'Natalie and Ryan vintage romantic wedding at Crossed Keys Inn with antique details and dusty rose palette',
    tall: true,
  },
  {
    id: 7,
    title: 'Jasmine & Thomas',
    venue: 'The Madison Hotel',
    style: 'Classic Luxury',
    season: 'Winter',
    image: 'https://placehold.co/800x600?text=Classic+luxury+winter+wedding+hotel+ballroom+white+roses+crystal+chandeliers+champagne+tones',
    alt: 'Jasmine and Thomas classic luxury winter wedding in hotel ballroom with crystal chandeliers',
    tall: false,
  },
  {
    id: 8,
    title: 'Mei & David',
    venue: 'Skylands Manor',
    style: 'Garden Romance',
    season: 'Spring',
    image: 'https://placehold.co/800x800?text=Spring+garden+wedding+Skylands+Manor+NJ+cherry+blossoms+pink+white+floral+ceremony+arch',
    alt: 'Mei and David spring garden wedding at Skylands Manor with cherry blossoms and pink floral arch',
    tall: false,
  },
  {
    id: 9,
    title: 'Layla & Marcus',
    venue: 'Teterboro Airport Hangar',
    style: 'Modern Minimalist',
    season: 'Fall',
    image: 'https://placehold.co/800x1000?text=Industrial+chic+wedding+hangar+dramatic+lighting+black+white+gold+suspended+florals+minimalist',
    alt: 'Layla and Marcus industrial chic wedding in hangar with dramatic lighting and suspended florals',
    tall: true,
  },
]

const venues = ['All', 'Park Chateau Estate', 'The Grand Ballroom', 'Natirar Mansion', 'Liberty House', "Nanina's In The Park", 'Crossed Keys Inn', 'The Madison Hotel', 'Skylands Manor', 'Teterboro Airport Hangar']
const styles = ['All', 'Garden Romance', 'Black Tie Elegance', 'Rustic Luxe', 'Modern Minimalist', 'South Asian Fusion', 'Vintage Romantic', 'Classic Luxury']
const seasons = ['All', 'Spring', 'Summer', 'Fall', 'Winter']

export default function PortfolioPage() {
  const [venueFilter, setVenueFilter] = useState('All')
  const [styleFilter, setStyleFilter] = useState('All')
  const [seasonFilter, setSeasonFilter] = useState('All')
  const [lightbox, setLightbox] = useState<number | null>(null)
  const sectionRef = useRef<HTMLDivElement>(null)

  const filtered = allWeddings.filter((w) => {
    if (venueFilter !== 'All' && w.venue !== venueFilter) return false
    if (styleFilter !== 'All' && w.style !== styleFilter) return false
    if (seasonFilter !== 'All' && w.season !== seasonFilter) return false
    return true
  })

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setLightbox(null)
      if (e.key === 'ArrowRight' && lightbox !== null)
        setLightbox((l) => l !== null ? (l + 1) % filtered.length : null)
      if (e.key === 'ArrowLeft' && lightbox !== null)
        setLightbox((l) => l !== null ? (l - 1 + filtered.length) % filtered.length : null)
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [lightbox, filtered.length])

  const FilterBar = ({ label, options, value, onChange }: { label: string; options: string[]; value: string; onChange: (v: string) => void }) => (
    <div className="flex flex-col gap-2">
      <span
        className="text-[0.55rem] tracking-[0.3em] uppercase"
        style={{ color: '#C9A84C' }}
      >
        {label}
      </span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="text-xs px-4 py-2.5 border appearance-none cursor-pointer transition-colors duration-300 focus:outline-none"
        style={{
          background: '#FFFDF7',
          borderColor: '#E2D9CC',
          color: '#2C2C2C',
          fontFamily: 'var(--font-jost)',
          fontWeight: 300,
          letterSpacing: '0.05em',
          minWidth: '180px',
        }}
      >
        {options.map((o) => (
          <option key={o} value={o}>{o}</option>
        ))}
      </select>
    </div>
  )

  return (
    <div ref={sectionRef}>
      <Navbar />

      {/* Page Hero */}
      <section
        className="relative flex items-end pb-20 pt-36 px-6"
        style={{ minHeight: '55vh', background: '#2C2C2C' }}
      >
        <img
          src="https://placehold.co/1920x700?text=Portfolio+of+luxury+NJ+weddings+cinematic+moody+editorial+collage+champagne+roses+golden+light"
          alt="Portfolio of luxury New Jersey weddings cinematic and editorial style"
          className="absolute inset-0 w-full h-full object-cover opacity-25"
        />
        <div className="relative z-10 max-w-4xl">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
            <span className="text-[0.6rem] tracking-[0.4em] uppercase" style={{ color: '#C9A84C' }}>
              Our Portfolio
            </span>
          </div>
          <h1
            className="text-5xl md:text-7xl"
            style={{ fontFamily: 'var(--font-playfair)', color: '#FFFDF7', lineHeight: '1.05' }}
          >
            Real Weddings,<br />
            <em style={{ color: '#C9A84C' }}>Real Magic</em>
          </h1>
        </div>
      </section>

      {/* Filters */}
      <section
        className="sticky top-[77px] z-40 py-5 px-6 lg:px-12 border-b"
        style={{ background: '#FFFDF7', borderColor: '#E2D9CC' }}
      >
        <div className="max-w-7xl mx-auto flex flex-wrap gap-6 items-end">
          <FilterBar label="Venue" options={venues} value={venueFilter} onChange={setVenueFilter} />
          <FilterBar label="Style" options={styles} value={styleFilter} onChange={setStyleFilter} />
          <FilterBar label="Season" options={seasons} value={seasonFilter} onChange={setSeasonFilter} />
          <button
            onClick={() => { setVenueFilter('All'); setStyleFilter('All'); setSeasonFilter('All') }}
            className="text-[0.6rem] tracking-[0.2em] uppercase pb-0.5 border-b transition-colors duration-300"
            style={{ color: '#B5AFA8', borderColor: '#B5AFA8', fontFamily: 'var(--font-jost)', alignSelf: 'flex-end', marginBottom: '2px' }}
          >
            Clear Filters
          </button>
          <span
            className="ml-auto text-xs"
            style={{ color: '#B5AFA8', fontFamily: 'var(--font-jost)', fontWeight: 300, alignSelf: 'flex-end', marginBottom: '4px' }}
          >
            {filtered.length} {filtered.length === 1 ? 'wedding' : 'weddings'}
          </span>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-16 px-6 lg:px-12" style={{ background: '#FAF6EF' }}>
        <div className="max-w-7xl mx-auto">
          {filtered.length === 0 ? (
            <div className="text-center py-24">
              <p className="text-2xl mb-4" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>
                No weddings match your filters
              </p>
              <button
                onClick={() => { setVenueFilter('All'); setStyleFilter('All'); setSeasonFilter('All') }}
                className="btn-outline-gold inline-block mt-4"
              >
                Clear Filters
              </button>
            </div>
          ) : (
            <div className="columns-1 sm:columns-2 lg:columns-3 gap-4 space-y-4">
              {filtered.map((wedding, i) => (
                <div key={wedding.id} className="break-inside-avoid">
                  <div
                    className="group relative overflow-hidden cursor-pointer reveal-on-scroll"
                    onClick={() => setLightbox(i)}
                    style={{ border: '1px solid #E2D9CC', transitionDelay: `${i * 60}ms` }}
                  >
                    <img
                      src={wedding.image}
                      alt={wedding.alt}
                      className="w-full object-cover transition-transform duration-700 group-hover:scale-105"
                      style={{ height: wedding.tall ? '500px' : '300px' }}
                    />
                    <div
                      className="absolute inset-0 flex flex-col justify-end p-6 opacity-0 group-hover:opacity-100 transition-all duration-500"
                      style={{ background: 'linear-gradient(to top, rgba(28,22,18,0.85) 0%, transparent 55%)' }}
                    >
                      <div className="w-6 h-px mb-3" style={{ background: '#C9A84C' }} />
                      <h3 className="text-lg text-[#FFFDF7] mb-1" style={{ fontFamily: 'var(--font-playfair)' }}>
                        {wedding.title}
                      </h3>
                      <p className="text-[0.6rem] tracking-[0.15em] uppercase" style={{ color: '#E2C97E' }}>
                        {wedding.venue} · {wedding.style}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6 text-center" style={{ background: '#FFFDF7' }}>
        <div className="max-w-xl mx-auto">
          <h2 className="text-3xl md:text-4xl mb-6" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>
            Ready to Create Your Own<br />
            <em className="gold-text">Love Story?</em>
          </h2>
          <Link href="/booking" className="btn-gold inline-block">
            Start Planning Your Wedding
          </Link>
        </div>
      </section>

      {/* Lightbox */}
      {lightbox !== null && filtered[lightbox] && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center"
          style={{ background: 'rgba(18,14,10,0.96)' }}
          onClick={() => setLightbox(null)}
        >
          <button
            className="absolute top-5 right-5 p-2 transition-colors"
            style={{ color: '#F5E6C8' }}
            onClick={() => setLightbox(null)}
            aria-label="Close"
          >
            <X size={26} />
          </button>
          <button
            className="absolute left-5 top-1/2 -translate-y-1/2 p-2 transition-colors hover:text-[#C9A84C]"
            style={{ color: '#F5E6C8' }}
            onClick={(e) => { e.stopPropagation(); setLightbox((l) => l !== null ? (l - 1 + filtered.length) % filtered.length : null) }}
            aria-label="Previous"
          >
            <ChevronLeft size={36} />
          </button>
          <div className="max-w-4xl max-h-[85vh] mx-20" onClick={(e) => e.stopPropagation()}>
            <img
              src={filtered[lightbox].image}
              alt={filtered[lightbox].alt}
              className="max-w-full max-h-[70vh] object-contain"
            />
            <div className="text-center mt-5">
              <h3 className="text-2xl mb-1" style={{ fontFamily: 'var(--font-playfair)', color: '#F5E6C8' }}>
                {filtered[lightbox].title}
              </h3>
              <p className="text-[0.6rem] tracking-[0.2em] uppercase" style={{ color: '#C9A84C' }}>
                {filtered[lightbox].venue} · {filtered[lightbox].style} · {filtered[lightbox].season}
              </p>
            </div>
          </div>
          <button
            className="absolute right-5 top-1/2 -translate-y-1/2 p-2 transition-colors hover:text-[#C9A84C]"
            style={{ color: '#F5E6C8' }}
            onClick={(e) => { e.stopPropagation(); setLightbox((l) => l !== null ? (l + 1) % filtered.length : null) }}
            aria-label="Next"
          >
            <ChevronRight size={36} />
          </button>
        </div>
      )}

      <Footer />
    </div>
  )
}
