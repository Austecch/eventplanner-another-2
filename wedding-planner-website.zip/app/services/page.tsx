'use client'

import { useEffect, useRef } from 'react'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import Link from 'next/link'
import { Check, ArrowRight } from 'lucide-react'

const services = [
  {
    id: 'full-planning',
    tag: 'Most Comprehensive',
    title: 'Full Wedding Planning',
    subtitle: 'From the first spark to the final farewell',
    description:
      'Our signature full planning experience is a complete, start-to-finish partnership. We immerse ourselves in your vision from the very first consultation and remain by your side through every single milestone — securing the perfect venue, curating an elite vendor team, designing every visual element, and flawlessly orchestrating your wedding day.',
    image: 'https://placehold.co/900x700?text=Full+wedding+planning+session+with+couple+reviewing+mood+boards+luxury+studio+champagne+floral+samples+elegant+table',
    alt: 'Full wedding planning session with couple reviewing mood boards and floral samples in luxury studio',
    priceHint: 'Starting at $8,500',
    features: [
      'Unlimited planning meetings & consultations',
      'Complete venue sourcing & contract review',
      'Full vendor team curation & negotiation',
      'Custom design concept & mood board',
      'Budget creation & management',
      'Guest experience coordination',
      'Rehearsal & rehearsal dinner planning',
      'Full wedding day management (12 hrs)',
    ],
    cta: '/booking',
    reverse: false,
  },
  {
    id: 'partial-planning',
    tag: 'Flexible Partnership',
    title: 'Partial Planning',
    subtitle: 'Already started? Let us elevate what you have.',
    description:
      'The Partial Planning package is designed for couples who have made some key decisions but need an expert to refine the vision, close the vendor gaps, and ensure everything comes together seamlessly. We step in where you need us most, providing structure, design guidance, and professional oversight.',
    image: 'https://placehold.co/900x700?text=Wedding+planner+reviewing+venue+layout+plans+with+engaged+couple+sunlit+NJ+ballroom+design+consultation',
    alt: 'Wedding planner reviewing venue layout plans with engaged couple in sunlit New Jersey ballroom',
    priceHint: 'Starting at $4,500',
    features: [
      'Up to 12 planning meetings',
      'Vendor recommendations & booking assistance',
      'Design concept refinement',
      'Month-of planning & logistics',
      'Final vendor confirmations',
      'Detailed day-of timeline',
      'Rehearsal coordination',
      'Full wedding day management (10 hrs)',
    ],
    cta: '/booking',
    reverse: true,
  },
  {
    id: 'day-of',
    tag: 'Stress-Free',
    title: 'Day-of Coordination',
    subtitle: 'Your vision. Our execution. Your presence.',
    description:
      'You\'ve planned every detail — now let us take the reins so you can breathe, be present, and enjoy every moment. Our Day-of Coordination begins 6 weeks before your wedding, allowing us to deeply understand your plans, confirm all vendors, and create a seamless timeline that ensures everything unfolds exactly as you envisioned.',
    image: 'https://placehold.co/900x700?text=Day+of+wedding+coordinator+directing+ceremony+setup+elegant+florals+aisle+candles+white+chairs+sunshine',
    alt: 'Day-of wedding coordinator directing ceremony setup with elegant florals and white chairs in sunshine',
    priceHint: 'Starting at $2,200',
    features: [
      '6-week lead-in planning sessions',
      'Vendor contact collection & confirmations',
      'Detailed timeline creation',
      'Ceremony rehearsal direction',
      'Venue setup oversight',
      'Full wedding day management (10 hrs)',
      'Emergency kit & contingency planning',
      'Post-event vendor gratuity distribution',
    ],
    cta: '/booking',
    reverse: false,
  },
  {
    id: 'destination',
    tag: 'Worldwide',
    title: 'Destination Weddings',
    subtitle: 'Extraordinary places. Extraordinary love.',
    description:
      'Whether you dream of exchanging vows on an Amalfi Coast terrace, a Caribbean beach, or a Tuscan vineyard, our Destination Wedding service handles every logistical and design challenge that comes with marrying abroad. We leverage our international vendor network to ensure your guests experience a seamless, awe-inspiring celebration no matter where in the world it takes place.',
    image: 'https://placehold.co/900x700?text=Destination+wedding+ceremony+cliffside+Mediterranean+venue+white+floral+arch+ocean+views+golden+sunset+light',
    alt: 'Destination wedding ceremony at cliffside Mediterranean venue with white floral arch and ocean views at golden sunset',
    priceHint: 'Custom Quote',
    features: [
      'International venue scouting & booking',
      'Local vendor network coordination',
      'Guest travel & accommodation management',
      'Legal requirements & documentation',
      'Custom cultural ceremony integration',
      'Pre-wedding events (welcome dinner, etc.)',
      'On-site planning team',
      'Full destination wedding management',
    ],
    cta: '/booking',
    reverse: true,
  },
]

export default function ServicesPage() {
  const pageRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll('.reveal-on-scroll').forEach((el, i) => {
              setTimeout(() => el.classList.add('revealed'), i * 100)
            })
          }
        })
      },
      { threshold: 0.08 }
    )
    pageRef.current?.querySelectorAll('section').forEach((s) => observer.observe(s))
    return () => observer.disconnect()
  }, [])

  return (
    <div ref={pageRef}>
      <Navbar />

      {/* Page Hero */}
      <section
        className="relative flex items-end pb-20 pt-36 px-6"
        style={{ minHeight: '60vh', background: '#1C1610' }}
      >
        <img
          src="https://placehold.co/1920x700?text=Luxury+wedding+planning+overhead+flatlay+invitation+suite+champagne+roses+ribbon+ivory+silk+tablecloth"
          alt="Luxury wedding planning flatlay with invitation suite, champagne roses and ivory silk tablecloth"
          className="absolute inset-0 w-full h-full object-cover opacity-25"
        />
        <div className="relative z-10 max-w-4xl">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
            <span className="text-[0.6rem] tracking-[0.4em] uppercase" style={{ color: '#C9A84C' }}>
              Services
            </span>
          </div>
          <h1
            className="text-5xl md:text-7xl"
            style={{ fontFamily: 'var(--font-playfair)', color: '#FFFDF7', lineHeight: '1.05' }}
          >
            Tailored to Every<br />
            <em style={{ color: '#C9A84C' }}>Love Story</em>
          </h1>
          <p
            className="mt-6 text-base max-w-xl"
            style={{ color: '#B5AFA8', fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.9' }}
          >
            From comprehensive full planning to seamless day-of coordination, each of our services
            is designed to give you exactly the level of support your wedding deserves.
          </p>
        </div>
      </section>

      {/* Service Sections */}
      {services.map((service, idx) => (
        <section
          key={service.id}
          id={service.id}
          className="py-28 px-6 lg:px-12"
          style={{ background: idx % 2 === 0 ? '#FFFDF7' : '#FAF6EF' }}
        >
          <div className="max-w-7xl mx-auto">
            <div className={`grid lg:grid-cols-2 gap-16 lg:gap-24 items-center ${service.reverse ? 'lg:grid-flow-dense' : ''}`}>
              {/* Image */}
              <div className={`reveal-on-scroll overflow-hidden ${service.reverse ? 'lg:col-start-2' : ''}`}>
                <img
                  src={service.image}
                  alt={service.alt}
                  className="w-full object-cover"
                  style={{ height: '500px' }}
                />
              </div>

              {/* Content */}
              <div className={service.reverse ? 'lg:col-start-1' : ''}>
                <div className="reveal-on-scroll">
                  <span
                    className="inline-block text-[0.55rem] tracking-[0.3em] uppercase px-3 py-1 mb-6"
                    style={{ background: '#F5E6C8', color: '#9B7A2F' }}
                  >
                    {service.tag}
                  </span>
                </div>
                <h2
                  className="text-3xl md:text-5xl mb-3 reveal-on-scroll"
                  style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}
                >
                  {service.title}
                </h2>
                <p
                  className="text-[0.65rem] tracking-[0.2em] uppercase mb-6 reveal-on-scroll"
                  style={{ color: '#C9A84C' }}
                >
                  {service.subtitle}
                </p>
                <p
                  className="text-sm leading-relaxed mb-8 reveal-on-scroll"
                  style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.9' }}
                >
                  {service.description}
                </p>

                {/* Features */}
                <ul className="space-y-3 mb-8 reveal-on-scroll">
                  {service.features.map((f) => (
                    <li key={f} className="flex items-start gap-3">
                      <Check size={14} className="shrink-0 mt-0.5" style={{ color: '#C9A84C' }} />
                      <span
                        className="text-sm"
                        style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300 }}
                      >
                        {f}
                      </span>
                    </li>
                  ))}
                </ul>

                <div className="flex items-center gap-6 reveal-on-scroll">
                  <Link href={service.cta} className="btn-gold inline-flex items-center gap-2">
                    Book a Consultation
                    <ArrowRight size={13} />
                  </Link>
                  <span
                    className="text-sm"
                    style={{ color: '#C9A84C', fontFamily: 'var(--font-playfair)', fontStyle: 'italic' }}
                  >
                    {service.priceHint}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>
      ))}

      {/* Comparison CTA */}
      <section
        className="py-24 px-6 text-center"
        style={{ background: '#1C1610' }}
      >
        <div className="max-w-2xl mx-auto reveal-on-scroll">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
            <span className="text-[0.6rem] tracking-[0.4em] uppercase" style={{ color: '#C9A84C' }}>
              Not Sure?
            </span>
            <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
          </div>
          <h2
            className="text-3xl md:text-5xl mb-6"
            style={{ fontFamily: 'var(--font-playfair)', color: '#F5E6C8' }}
          >
            Let&apos;s Find the Perfect<br />
            <em style={{ color: '#C9A84C' }}>Package for You</em>
          </h2>
          <p
            className="text-sm mb-10"
            style={{ color: '#B5AFA8', fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.9' }}
          >
            Every wedding is different. Book a complimentary discovery call and we&apos;ll guide you to
            the service that best matches your vision, timeline, and needs.
          </p>
          <Link href="/booking" className="btn-gold inline-block">
            Request a Free Discovery Call
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  )
}
