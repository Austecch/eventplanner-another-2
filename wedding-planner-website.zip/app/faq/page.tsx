'use client'

import { useState, useEffect, useRef } from 'react'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import Link from 'next/link'
import { Plus, Minus } from 'lucide-react'

const faqs = [
  {
    category: 'Getting Started',
    questions: [
      {
        q: 'How far in advance should we book Veil & Bloom?',
        a: 'We recommend reaching out at least 12–18 months before your wedding date, especially for peak seasons (May–October). We accept a limited number of weddings per year to ensure every couple receives our full attention, and popular dates book quickly. That said, we occasionally have availability for shorter timelines — please enquire.',
      },
      {
        q: 'What is included in the initial consultation?',
        a: 'Your complimentary discovery call is a 30-minute conversation where we learn about your vision, answer all your questions, and determine which of our services best fits your needs. There is no commitment or obligation. We simply want to ensure we are the right fit for each other before moving forward.',
      },
      {
        q: 'Do you work exclusively with weddings in New Jersey?',
        a: 'Our home base is New Jersey and we know every premier venue in the state intimately. However, we regularly plan weddings in New York, Connecticut, and throughout the Northeast. We also offer full destination wedding services internationally — from Europe to the Caribbean to Southeast Asia.',
      },
    ],
  },
  {
    category: 'Our Services',
    questions: [
      {
        q: 'What is the difference between Full Planning and Partial Planning?',
        a: 'Full Planning is our most comprehensive service — we are involved from day one through your final farewell, handling everything from venue scouting to vendor negotiations to design. Partial Planning is for couples who have already made some key decisions and need an expert to step in, refine the vision, and manage logistics. Both include full wedding day management.',
      },
      {
        q: 'Can we customize a package to suit our specific needs?',
        a: 'Absolutely. We understand that every couple\'s needs are unique. After your discovery call, we can tailor a bespoke proposal that combines elements from different service tiers. Our goal is always to give you exactly what you need — no more, no less.',
      },
      {
        q: 'Do you handle the rehearsal dinner as well?',
        a: 'Yes. Our Full Planning package includes rehearsal dinner coordination. For other packages, rehearsal dinner planning can be added as an à la carte service. We can handle everything from the venue to the florals to the menu.',
      },
    ],
  },
  {
    category: 'Vendors & Design',
    questions: [
      {
        q: 'Do we have to use your preferred vendors?',
        a: 'Not at all. We have a curated network of New Jersey\'s finest photographers, florists, caterers, and entertainment professionals that we trust and love working with. However, if you have existing relationships with vendors or have already made bookings, we will work seamlessly with your team. We will always advocate for your vision first.',
      },
      {
        q: 'How do you approach wedding design and aesthetics?',
        a: 'Design is at the heart of everything we do. We begin with a deep dive into your personal style — your wardrobe, your home, your travels, your Pinterest boards — to develop a bespoke visual concept. From there, we create a comprehensive design package including mood boards, color palettes, floral direction, and tabletop styling.',
      },
      {
        q: 'Can you source vendors for a destination wedding in another country?',
        a: 'Yes. We have an established international vendor network and relationships with destination wedding specialists across Europe, the Caribbean, Mexico, and beyond. We handle all communication, contracts, and logistical coordination across time zones so you never have to navigate it alone.',
      },
    ],
  },
  {
    category: 'Budgets & Pricing',
    questions: [
      {
        q: 'What is the starting price for your services?',
        a: 'Our Day-of Coordination starts at $2,200, Partial Planning from $4,500, and Full Wedding Planning from $8,500. Destination wedding pricing is customized based on scale and location. We are transparent about pricing from the start and can provide a detailed proposal after your discovery call.',
      },
      {
        q: 'Do you help manage and track the overall wedding budget?',
        a: 'Yes — budget management is a core part of our Full and Partial Planning services. We create a master budget spreadsheet, track all deposits and payments, flag where costs may escalate, and make recommendations to maximize your investment. Our goal is to ensure you never experience budget surprises.',
      },
      {
        q: 'Is a deposit required to secure our date?',
        a: 'Yes. Upon signing your contract, we require a 25% retainer to officially hold your wedding date and begin planning. The remaining balance is structured in installments leading up to your wedding day, as outlined in your contract.',
      },
    ],
  },
  {
    category: 'The Wedding Day',
    questions: [
      {
        q: 'How many coordinators will be present on our wedding day?',
        a: 'The number of coordinators depends on the size and complexity of your event. For most weddings, you will have a lead planner plus one or two assistant coordinators. For larger or multi-venue events, we scale our team accordingly. You will always know exactly who will be there and their specific roles.',
      },
      {
        q: 'What happens if something goes wrong on the day?',
        a: 'Contingency planning is built into everything we do. We maintain an emergency kit, develop backup plans for weather, vendor no-shows, and timeline delays. Our team is trained to handle crises calmly and discreetly so that you never feel the pressure. In our 12+ years, we have never had a wedding day fail.',
      },
    ],
  },
]

export default function FAQPage() {
  const [open, setOpen] = useState<string | null>(null)
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll('.reveal-on-scroll').forEach((el, i) => {
              setTimeout(() => el.classList.add('revealed'), i * 80)
            })
          }
        })
      },
      { threshold: 0.05 }
    )
    sectionRef.current?.querySelectorAll('section').forEach((s) => observer.observe(s))
    return () => observer.disconnect()
  }, [])

  return (
    <div ref={sectionRef}>
      <Navbar />

      {/* Hero */}
      <section
        className="relative flex items-end pb-20 pt-36 px-6"
        style={{ minHeight: '50vh', background: '#FAF6EF' }}
      >
        <div className="relative z-10 max-w-4xl">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
            <span className="text-[0.6rem] tracking-[0.4em] uppercase" style={{ color: '#C9A84C' }}>
              FAQ
            </span>
          </div>
          <h1
            className="text-5xl md:text-7xl mb-6"
            style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C', lineHeight: '1.05' }}
          >
            Everything You<br />
            <em className="gold-text">Need to Know</em>
          </h1>
          <p
            className="text-base max-w-xl"
            style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.9' }}
          >
            Planning a wedding is full of questions. We have compiled the answers to the ones
            couples ask us most often. Still have questions? We love to talk.
          </p>
        </div>
      </section>

      {/* FAQ Sections */}
      <section className="py-20 px-6 lg:px-12" style={{ background: '#FFFDF7' }}>
        <div className="max-w-3xl mx-auto space-y-16">
          {faqs.map((group, gi) => (
            <div key={group.category} className="reveal-on-scroll" style={{ transitionDelay: `${gi * 80}ms` }}>
              {/* Category Label */}
              <div className="flex items-center gap-4 mb-8">
                <span
                  className="text-[0.6rem] tracking-[0.35em] uppercase"
                  style={{ color: '#C9A84C', fontFamily: 'var(--font-jost)' }}
                >
                  {group.category}
                </span>
                <div className="flex-1 h-px" style={{ background: 'linear-gradient(to right, #C9A84C, transparent)' }} />
              </div>

              {/* Questions */}
              <div className="space-y-2">
                {group.questions.map((item, qi) => {
                  const key = `${gi}-${qi}`
                  const isOpen = open === key
                  return (
                    <div
                      key={qi}
                      className="border transition-colors duration-300"
                      style={{
                        borderColor: isOpen ? '#C9A84C' : '#E2D9CC',
                        background: isOpen ? '#FFFCF3' : '#FFFDF7',
                      }}
                    >
                      <button
                        className="w-full flex items-start justify-between gap-6 p-6 text-left"
                        onClick={() => setOpen(isOpen ? null : key)}
                        aria-expanded={isOpen}
                      >
                        <span
                          className="text-base md:text-lg leading-snug"
                          style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}
                        >
                          {item.q}
                        </span>
                        <span
                          className="shrink-0 w-7 h-7 rounded-full border flex items-center justify-center transition-all duration-300 mt-0.5"
                          style={{
                            borderColor: isOpen ? '#C9A84C' : '#E2D9CC',
                            color: isOpen ? '#C9A84C' : '#7A7068',
                          }}
                        >
                          {isOpen ? <Minus size={13} /> : <Plus size={13} />}
                        </span>
                      </button>

                      <div
                        className="overflow-hidden transition-all duration-500"
                        style={{ maxHeight: isOpen ? '600px' : '0', opacity: isOpen ? 1 : 0 }}
                      >
                        <div className="px-6 pb-6 pt-0">
                          <div className="w-6 h-px mb-4" style={{ background: '#C9A84C' }} />
                          <p
                            className="text-sm leading-relaxed"
                            style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.9' }}
                          >
                            {item.a}
                          </p>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Still have questions CTA */}
      <section
        className="py-20 px-6 text-center"
        style={{ background: '#FAF6EF', borderTop: '1px solid #E2D9CC' }}
      >
        <div className="max-w-xl mx-auto">
          <h2 className="text-3xl md:text-4xl mb-4" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>
            Still Have Questions?
          </h2>
          <p className="text-sm mb-8" style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.9' }}>
            Our team is always happy to chat. Reach out directly — we love getting to know
            the couples we work with, even before a commitment is made.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/contact" className="btn-gold inline-block">
              Contact Us
            </Link>
            <Link href="/booking" className="btn-outline-gold inline-block">
              Book a Discovery Call
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
