'use client'

import { useEffect, useRef } from 'react'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import Link from 'next/link'

const team = [
  {
    name: 'Isabelle Laurent',
    role: 'Founder & Lead Planner',
    bio: 'With 12 years shaping New Jersey\'s luxury wedding scene, Isabelle founded Veil & Bloom on the belief that every love story deserves a cinematic telling.',
    image: 'https://placehold.co/500x600?text=Elegant+female+wedding+planner+professional+portrait+soft+natural+light+warm+ivory+background+blush+tones',
    alt: 'Isabelle Laurent, founder and lead planner, professional portrait',
  },
  {
    name: 'Charlotte Vance',
    role: 'Creative Director',
    bio: 'Charlotte\'s editorial eye and deep knowledge of florals, lighting, and design transforms each wedding into a breathtaking visual narrative.',
    image: 'https://placehold.co/500x600?text=Creative+director+woman+with+mood+boards+florals+elegant+studio+setting+soft+champagne+tones',
    alt: 'Charlotte Vance, creative director, with mood boards and florals',
  },
  {
    name: 'Naomi Rivers',
    role: 'Senior Event Coordinator',
    bio: 'Naomi\'s meticulous logistics expertise ensures that no detail falls through the cracks — from vendor timelines to the final song of the night.',
    image: 'https://placehold.co/500x600?text=Professional+event+coordinator+woman+smiling+outdoor+garden+setting+soft+natural+daylight',
    alt: 'Naomi Rivers, senior event coordinator, outdoors in garden setting',
  },
]

const values = [
  { title: 'Intentional Design', text: 'We believe a wedding should feel like an extension of who you are — beautifully designed with purpose, never generic.' },
  { title: 'Emotional Storytelling', text: 'Every element we place, every moment we craft, is designed to evoke genuine emotion in you and your guests.' },
  { title: 'Flawless Execution', text: 'Behind every seamless wedding day is weeks of meticulous planning, vendor coordination, and contingency thinking.' },
  { title: 'Devoted Partnership', text: 'We become your most trusted advocates — championing your vision, protecting your budget, and celebrating your love.' },
]

export default function AboutPage() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll('.reveal-on-scroll').forEach((el, i) => {
              setTimeout(() => el.classList.add('revealed'), i * 100)
            })
          }
        })
      },
      { threshold: 0.1 }
    )
    const els = sectionRef.current?.querySelectorAll('section') || []
    els.forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [])

  return (
    <div ref={sectionRef}>
      <Navbar />

      {/* Page Hero */}
      <section
        className="relative flex items-end pb-20 pt-36 px-6"
        style={{ minHeight: '60vh', background: '#2C2C2C' }}
      >
        <img
          src="https://placehold.co/1920x700?text=Behind+the+scenes+wedding+planning+studio+team+collaboration+floral+arrangements+mood+boards+elegant+workspace"
          alt="Veil and Bloom planning studio behind the scenes with team collaboration and mood boards"
          className="absolute inset-0 w-full h-full object-cover opacity-30"
        />
        <div className="relative z-10 max-w-4xl">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
            <span className="text-[0.6rem] tracking-[0.4em] uppercase" style={{ color: '#C9A84C' }}>
              Our Story
            </span>
          </div>
          <h1
            className="text-5xl md:text-7xl lg:text-8xl"
            style={{ fontFamily: 'var(--font-playfair)', color: '#FFFDF7', lineHeight: '1.05' }}
          >
            We Believe in<br />
            <em style={{ color: '#C9A84C' }}>Beautiful Beginnings</em>
          </h1>
        </div>
      </section>

      {/* Brand Story */}
      <section
        className="py-32 px-6 lg:px-12"
        style={{ background: '#FFFDF7' }}
      >
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-20 items-center">
          <div>
            <h2
              className="text-3xl md:text-5xl mb-8 reveal-on-scroll"
              style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}
            >
              More Than a Wedding Company —<br />
              <em className="gold-text">We Are Storytellers</em>
            </h2>
            <div
              className="space-y-5 reveal-on-scroll"
              style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.9', fontSize: '0.95rem' }}
            >
              <p>
                Veil &amp; Bloom was born from a simple truth: the most important day of your life
                deserves more than just competent execution. It deserves artistry.
              </p>
              <p>
                Founded in 2013 by Isabelle Laurent in Princeton, New Jersey, we set out to redefine
                what luxury wedding planning could feel like — not transactional, but transformational.
                Not just organized, but emotionally resonant.
              </p>
              <p>
                Over the past decade, we have had the extraordinary privilege of crafting over 300
                wedding experiences across New Jersey and beyond. Each one told a unique love story
                through immaculate design, flawless logistics, and genuine human connection.
              </p>
              <p>
                Our philosophy is simple: your wedding should feel like you. Elevated, intentional,
                and utterly unforgettable.
              </p>
            </div>
            <div className="mt-10 reveal-on-scroll">
              <Link href="/booking" className="btn-gold inline-block">
                Begin Your Story
              </Link>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 reveal-on-scroll">
            <img
              src="https://placehold.co/400x500?text=Wedding+planner+with+bride+reviewing+design+concepts+intimate+consultation+warm+studio+light"
              alt="Wedding planner consulting with bride over design concepts in warm studio lighting"
              className="object-cover w-full"
              style={{ height: '300px' }}
            />
            <img
              src="https://placehold.co/400x500?text=Luxury+floral+arrangement+design+process+premium+garden+roses+peonies+champagne+ivory+palette"
              alt="Luxury floral arrangement design with premium garden roses and peonies in champagne and ivory palette"
              className="object-cover w-full mt-12"
              style={{ height: '300px' }}
            />
          </div>
        </div>
      </section>

      {/* Philosophy */}
      <section
        className="py-32 px-6 lg:px-12"
        style={{ background: '#FAF6EF' }}
      >
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <div className="reveal-on-scroll inline-flex items-center gap-3 mb-6">
              <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
              <span className="text-[0.6rem] tracking-[0.4em] uppercase" style={{ color: '#C9A84C' }}>
                Our Philosophy
              </span>
              <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
            </div>
            <h2
              className="text-4xl md:text-5xl reveal-on-scroll"
              style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}
            >
              Four Pillars of Our Practice
            </h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((v, i) => (
              <div
                key={v.title}
                className="reveal-on-scroll p-8 border-t-2"
                style={{ borderColor: '#C9A84C', transitionDelay: `${i * 100}ms` }}
              >
                <div
                  className="text-4xl mb-4"
                  style={{
                    fontFamily: 'var(--font-playfair)',
                    color: 'rgba(201,168,76,0.2)',
                    lineHeight: 1,
                  }}
                >
                  {String(i + 1).padStart(2, '0')}
                </div>
                <h3
                  className="text-xl mb-4"
                  style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}
                >
                  {v.title}
                </h3>
                <p
                  className="text-sm leading-relaxed"
                  style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.8' }}
                >
                  {v.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section
        className="py-32 px-6 lg:px-12"
        style={{ background: '#FFFDF7' }}
      >
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <div className="reveal-on-scroll inline-flex items-center gap-3 mb-6">
              <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
              <span className="text-[0.6rem] tracking-[0.4em] uppercase" style={{ color: '#C9A84C' }}>
                The Team
              </span>
              <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
            </div>
            <h2
              className="text-4xl md:text-5xl reveal-on-scroll"
              style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}
            >
              The Hearts Behind<br />
              <em className="gold-text">Every Wedding</em>
            </h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-10">
            {team.map((member, i) => (
              <div
                key={member.name}
                className="group reveal-on-scroll"
                style={{ transitionDelay: `${i * 120}ms` }}
              >
                <div className="overflow-hidden mb-6" style={{ height: '420px' }}>
                  <img
                    src={member.image}
                    alt={member.alt}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                <div
                  className="w-8 h-px mb-4"
                  style={{ background: '#C9A84C' }}
                />
                <h3
                  className="text-2xl mb-1"
                  style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}
                >
                  {member.name}
                </h3>
                <div
                  className="text-[0.65rem] tracking-[0.2em] uppercase mb-4"
                  style={{ color: '#C9A84C' }}
                >
                  {member.role}
                </div>
                <p
                  className="text-sm leading-relaxed"
                  style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.8' }}
                >
                  {member.bio}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
