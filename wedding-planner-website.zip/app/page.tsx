import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import HeroSection from '@/components/home/HeroSection'
import AboutPreview from '@/components/home/AboutPreview'
import ServicesOverview from '@/components/home/ServicesOverview'
import FeaturedWeddings from '@/components/home/FeaturedWeddings'
import ProcessTimeline from '@/components/home/ProcessTimeline'
import Testimonials from '@/components/home/Testimonials'
import HomeCTA from '@/components/home/HomeCTA'

export default function HomePage() {
  return (
    <main>
      <Navbar />
      <HeroSection />
      <AboutPreview />
      <ServicesOverview />
      <FeaturedWeddings />
      <ProcessTimeline />
      <Testimonials />
      <HomeCTA />
      <Footer />
    </main>
  )
}
