'use client'

import { useState } from 'react'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import { Mail, Phone, MapPin, Instagram, Facebook, Pinterest, Check } from 'lucide-react'

export default function ContactPage() {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', message: '' })
  const [submitted, setSubmitted] = useState(false)

  const update = (field: string, value: string) => setFormData((p) => ({ ...p, [field]: value }))

  const inputClass = `w-full border px-4 py-3.5 text-sm focus:outline-none transition-colors duration-300 focus:border-[#C9A84C]`
  const inputStyle = {
    background: '#FFFDF7',
    borderColor: '#E2D9CC',
    color: '#2C2C2C',
    fontFamily: 'var(--font-jost)',
    fontWeight: 300,
  }
  const labelStyle = {
    color: '#C9A84C',
    fontFamily: 'var(--font-jost)',
    fontSize: '0.6rem',
    letterSpacing: '0.25em',
    textTransform: 'uppercase' as const,
    display: 'block',
    marginBottom: '0.5rem',
  }

  return (
    <div>
      <Navbar />

      {/* Hero */}
      <section
        className="relative flex items-end pb-20 pt-36 px-6"
        style={{ minHeight: '50vh', background: '#1C1610' }}
      >
        <img
          src="https://placehold.co/1920x600?text=New+Jersey+landscape+aerial+view+rolling+hills+golden+afternoon+light+luxury+estate+grounds"
          alt="New Jersey aerial landscape with rolling hills and golden afternoon light"
          className="absolute inset-0 w-full h-full object-cover opacity-20"
        />
        <div className="relative z-10 max-w-4xl">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
            <span className="text-[0.6rem] tracking-[0.4em] uppercase" style={{ color: '#C9A84C' }}>
              Say Hello
            </span>
          </div>
          <h1
            className="text-5xl md:text-7xl"
            style={{ fontFamily: 'var(--font-playfair)', color: '#FFFDF7', lineHeight: '1.05' }}
          >
            Let&apos;s Start a<br />
            <em style={{ color: '#C9A84C' }}>Conversation</em>
          </h1>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-24 px-6 lg:px-12" style={{ background: '#FAF6EF' }}>
        <div className="max-w-7xl mx-auto grid lg:grid-cols-5 gap-16">

          {/* Left — Contact Info */}
          <div className="lg:col-span-2 space-y-10">
            <div>
              <h2
                className="text-3xl md:text-4xl mb-6"
                style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}
              >
                We&apos;d Love to<br />
                <em className="gold-text">Hear From You</em>
              </h2>
              <p
                className="text-sm leading-relaxed"
                style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.9' }}
              >
                Whether you have questions about our services, want to check availability, or simply
                want to share your vision — our studio is always open. Reach out and we will respond
                within 24 hours.
              </p>
            </div>

            <div className="space-y-6">
              {[
                { icon: Phone, label: 'Call Us', value: '+1 (908) 555-0192', href: 'tel:+19085550192' },
                { icon: Mail, label: 'Email Us', value: 'hello@veilandbloom.com', href: 'mailto:hello@veilandbloom.com' },
                { icon: MapPin, label: 'Studio', value: '12 Prospect Street, Morristown, NJ 07960', href: '#map' },
              ].map(({ icon: Icon, label, value, href }) => (
                <a
                  key={label}
                  href={href}
                  className="flex items-start gap-4 group"
                >
                  <div
                    className="w-10 h-10 border flex items-center justify-center shrink-0 transition-all duration-300 group-hover:border-[#C9A84C]"
                    style={{ borderColor: '#E2D9CC' }}
                  >
                    <Icon size={15} style={{ color: '#C9A84C' }} />
                  </div>
                  <div>
                    <div style={{ ...labelStyle, marginBottom: '0.2rem' }}>{label}</div>
                    <span
                      className="text-sm transition-colors duration-300 group-hover:text-[#C9A84C]"
                      style={{ color: '#2C2C2C', fontFamily: 'var(--font-jost)', fontWeight: 300 }}
                    >
                      {value}
                    </span>
                  </div>
                </a>
              ))}
            </div>

            {/* Studio Hours */}
            <div
              className="p-6 border"
              style={{ borderColor: '#E2D9CC', background: '#FFFDF7' }}
            >
              <div style={labelStyle}>Studio Hours</div>
              <div className="space-y-2 mt-3">
                {[
                  ['Monday – Friday', '9:00 AM – 6:00 PM'],
                  ['Saturday', 'By Appointment'],
                  ['Sunday', 'Closed'],
                ].map(([day, hours]) => (
                  <div key={day} className="flex justify-between">
                    <span className="text-xs" style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>{day}</span>
                    <span className="text-xs" style={{ color: '#2C2C2C', fontFamily: 'var(--font-jost)', fontWeight: 400 }}>{hours}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Social Links */}
            <div>
              <div style={labelStyle}>Follow Our Journey</div>
              <div className="flex gap-3 mt-3">
                {[
                  { icon: Instagram, label: 'Instagram' },
                  { icon: Pinterest, label: 'Pinterest' },
                  { icon: Facebook, label: 'Facebook' },
                ].map(({ icon: Icon, label }) => (
                  <a
                    key={label}
                    href="#"
                    aria-label={label}
                    className="w-10 h-10 border flex items-center justify-center transition-all duration-300 hover:border-[#C9A84C] hover:text-[#C9A84C]"
                    style={{ borderColor: '#E2D9CC', color: '#7A7068' }}
                  >
                    <Icon size={15} />
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Right — Form */}
          <div
            className="lg:col-span-3 p-8 md:p-12"
            style={{ background: '#FFFDF7', border: '1px solid #E2D9CC' }}
          >
            {submitted ? (
              <div className="flex flex-col items-center justify-center h-full text-center py-16">
                <div
                  className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6"
                  style={{ background: 'linear-gradient(135deg, #9B7A2F, #C9A84C)' }}
                >
                  <Check size={24} color="#FFFDF7" />
                </div>
                <h3 className="text-2xl mb-3" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>
                  Message Received
                </h3>
                <p className="text-sm" style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>
                  Thank you for reaching out. We will be in touch within 24 hours.
                </p>
              </div>
            ) : (
              <>
                <h3 className="text-2xl mb-2" style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}>
                  Send a Message
                </h3>
                <p className="text-sm mb-8" style={{ color: '#B5AFA8', fontFamily: 'var(--font-jost)', fontWeight: 300 }}>
                  Fill in the form below and we will get back to you shortly
                </p>

                <div className="space-y-5">
                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label style={labelStyle}>Full Name</label>
                      <input className={inputClass} style={inputStyle} value={formData.name} onChange={(e) => update('name', e.target.value)} placeholder="Your full name" />
                    </div>
                    <div>
                      <label style={labelStyle}>Email Address</label>
                      <input type="email" className={inputClass} style={inputStyle} value={formData.email} onChange={(e) => update('email', e.target.value)} placeholder="hello@example.com" />
                    </div>
                  </div>
                  <div>
                    <label style={labelStyle}>Phone Number (Optional)</label>
                    <input type="tel" className={inputClass} style={inputStyle} value={formData.phone} onChange={(e) => update('phone', e.target.value)} placeholder="+1 (908) 555-0100" />
                  </div>
                  <div>
                    <label style={labelStyle}>Your Message</label>
                    <textarea
                      className={inputClass}
                      style={{ ...inputStyle, resize: 'none' }}
                      rows={6}
                      value={formData.message}
                      onChange={(e) => update('message', e.target.value)}
                      placeholder="Tell us about your wedding vision, questions, or how we can help..."
                    />
                  </div>
                  <button
                    onClick={() => setSubmitted(true)}
                    className="btn-gold w-full text-center"
                  >
                    Send Message
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </section>

      {/* Map */}
      <section id="map" className="h-80 w-full relative" style={{ background: '#E8E0D5' }}>
        <img
          src="https://placehold.co/1920x400?text=Map+of+Morristown+New+Jersey+showing+studio+location+at+12+Prospect+Street+NJ+07960"
          alt="Map showing Veil and Bloom studio location in Morristown, New Jersey"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <div
            className="px-8 py-5 shadow-xl text-center"
            style={{ background: '#FFFDF7', border: '1px solid #E2D9CC' }}
          >
            <div
              className="text-xs tracking-[0.2em] uppercase mb-1"
              style={{ color: '#C9A84C' }}
            >
              Our Studio
            </div>
            <div
              className="text-base"
              style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}
            >
              12 Prospect Street<br />
              Morristown, NJ 07960
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
