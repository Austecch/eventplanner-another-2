import Link from 'next/link'
import { Instagram, Facebook, Pinterest, Mail, Phone, MapPin } from 'lucide-react'

export default function Footer() {
  return (
    <footer style={{ background: '#1C1610', color: '#F5E6C8' }}>
      {/* Ticker */}
      <div className="border-y border-[#C9A84C]/20 py-3 overflow-hidden">
        <div className="ticker-track animate-ticker whitespace-nowrap">
          {Array.from({ length: 10 }).map((_, i) => (
            <span
              key={i}
              className="inline-flex items-center gap-6 px-8 text-[0.6rem] tracking-[0.35em] uppercase text-[#C9A84C]"
              style={{ fontFamily: 'var(--font-jost)' }}
            >
              Veil &amp; Bloom
              <span className="inline-block w-1 h-1 rounded-full bg-[#C9A84C]" />
              Luxury Wedding Planning
              <span className="inline-block w-1 h-1 rounded-full bg-[#C9A84C]" />
              New Jersey
              <span className="inline-block w-1 h-1 rounded-full bg-[#C9A84C]" />
            </span>
          ))}
        </div>
      </div>

      {/* Top CTA */}
      <div className="py-20 px-6 text-center border-b border-[#3A2E22]">
        <p className="text-[0.62rem] tracking-[0.35em] uppercase text-[#C9A84C] mb-4">
          Begin Your Journey
        </p>
        <h2
          className="text-4xl md:text-5xl mb-6 leading-tight text-[#F5E6C8]"
          style={{ fontFamily: 'var(--font-playfair)' }}
        >
          Your Love Story Deserves<br />
          <em>an Unforgettable Day</em>
        </h2>
        <Link href="/booking" className="btn-gold inline-block mt-2">
          <span>Start Planning Today</span>
        </Link>
      </div>

      <div className="max-w-[1400px] mx-auto px-6 lg:px-14 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div
              className="text-3xl mb-2 tracking-wider text-[#F5E6C8]"
              style={{ fontFamily: 'var(--font-playfair)' }}
            >
              Veil &amp; Bloom
            </div>
            <div className="text-[0.6rem] tracking-[0.3em] uppercase text-[#C9A84C] mb-6">
              Wedding Planning · New Jersey
            </div>
            <p
              className="text-sm leading-relaxed max-w-sm mb-8 text-[#B5AFA8]"
              style={{ fontFamily: 'var(--font-jost)', fontWeight: 300 }}
            >
              We craft timeless, cinematic wedding experiences across New Jersey and beyond.
              Every detail curated. Every moment cherished. Every love story uniquely told.
            </p>
            <div className="flex gap-4">
              {[
                { icon: Instagram, label: 'Instagram' },
                { icon: Pinterest, label: 'Pinterest' },
                { icon: Facebook, label: 'Facebook' },
              ].map(({ icon: Icon, label }) => (
                <a
                  key={label}
                  href="#"
                  aria-label={label}
                  className="w-10 h-10 border border-[#3A2E22] flex items-center justify-center text-[#B5AFA8] transition-all duration-300 hover:border-[#C9A84C] hover:text-[#C9A84C]"
                >
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-[0.65rem] tracking-[0.3em] uppercase text-[#C9A84C] mb-6">
              Quick Links
            </h4>
            <ul className="space-y-3">
              {[
                { label: 'About', href: '/about' },
                { label: 'Services', href: '/services' },
                { label: 'Portfolio', href: '/portfolio' },
                { label: 'FAQ', href: '/faq' },
                { label: 'Book a Consultation', href: '/booking' },
                { label: 'Contact', href: '/contact' },
              ].map((item) => (
                <li key={item.label}>
                  <Link
                    href={item.href}
                    className="text-sm text-[#B5AFA8] hover:text-[#C9A84C] transition-colors duration-300"
                    style={{ fontFamily: 'var(--font-jost)', fontWeight: 300, letterSpacing: '0.05em' }}
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-[0.65rem] tracking-[0.3em] uppercase text-[#C9A84C] mb-6">
              Contact
            </h4>
            <ul className="space-y-4">
              {[
                { icon: Phone, text: '+1 (908) 555-0192' },
                { icon: Mail, text: 'hello@veilandbloom.com' },
                { icon: MapPin, text: 'Morristown, New Jersey, USA' },
              ].map(({ icon: Icon, text }) => (
                <li key={text} className="flex items-start gap-3">
                  <Icon size={14} className="text-[#C9A84C] mt-0.5 shrink-0" />
                  <span
                    className="text-sm text-[#B5AFA8] leading-relaxed"
                    style={{ fontFamily: 'var(--font-jost)', fontWeight: 300 }}
                  >
                    {text}
                  </span>
                </li>
              ))}
            </ul>
            <div className="mt-8">
              <h4 className="text-[0.65rem] tracking-[0.3em] uppercase text-[#C9A84C] mb-3">
                Studio Hours
              </h4>
              <p
                className="text-sm text-[#B5AFA8]"
                style={{ fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.9' }}
              >
                Mon – Fri: 9am – 6pm<br />
                Sat: By Appointment<br />
                Sun: Closed
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-[#3A2E22] py-6 px-6">
        <div className="max-w-[1400px] mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-[0.62rem] tracking-widest uppercase text-[#5C5248]">
            &copy; {new Date().getFullYear()} Veil &amp; Bloom. All rights reserved.
          </p>
          <div className="flex gap-6">
            {['Privacy Policy', 'Terms of Service', 'Sitemap'].map((item) => (
              <a
                key={item}
                href="#"
                className="text-[0.62rem] tracking-widest uppercase text-[#5C5248] hover:text-[#C9A84C] transition-colors"
              >
                {item}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
