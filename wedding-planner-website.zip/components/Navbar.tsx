'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Menu, X } from 'lucide-react'

const navLinks = [
  { label: 'About', href: '/about' },
  { label: 'Services', href: '/services' },
  { label: 'Portfolio', href: '/portfolio' },
  { label: 'FAQ', href: '/faq' },
  { label: 'Contact', href: '/contact' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const pathname = usePathname()

  const isDashboard =
    pathname?.startsWith('/dashboard') || pathname?.startsWith('/admin')

  const isHomePage = pathname === '/'
  const transparentTop = isHomePage && !scrolled

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    setMenuOpen(false)
    document.body.style.overflow = ''
  }, [pathname])

  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : ''
    return () => { document.body.style.overflow = '' }
  }, [menuOpen])

  if (isDashboard) return null

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ${
          transparentTop
            ? 'bg-transparent'
            : 'bg-[#FFFDF7]/96 backdrop-blur-md border-b border-[#E2D9CC]/50 shadow-sm'
        }`}
      >
        <div className="max-w-[1400px] mx-auto px-6 lg:px-14 flex items-center justify-between h-[78px]">
          {/* Logo */}
          <Link href="/" className="flex flex-col leading-none z-10">
            <span
              className={`text-[1.35rem] tracking-[0.08em] transition-colors duration-500 ${
                transparentTop ? 'text-[#FFFDF7]' : 'text-[#2C2C2C]'
              }`}
              style={{ fontFamily: 'var(--font-playfair)' }}
            >
              Veil &amp; Bloom
            </span>
            <span
              className="text-[0.58rem] tracking-[0.32em] uppercase font-light text-[#C9A84C]"
              style={{ fontFamily: 'var(--font-jost)' }}
            >
              Wedding Artisans · NJ
            </span>
          </Link>

          {/* Desktop links */}
          <ul className="hidden lg:flex items-center gap-9 list-none m-0 p-0">
            {navLinks.map((link) => (
              <li key={link.href}>
                <Link
                  href={link.href}
                  className={`text-[0.68rem] tracking-[0.22em] uppercase font-light relative group transition-colors duration-400 ${
                    pathname === link.href
                      ? 'text-[#C9A84C]'
                      : transparentTop
                      ? 'text-[#FFFDF7] hover:text-[#E2C97E]'
                      : 'text-[#2C2C2C] hover:text-[#C9A84C]'
                  }`}
                  style={{ fontFamily: 'var(--font-jost)' }}
                >
                  {link.label}
                  <span
                    className={`absolute -bottom-0.5 left-0 h-px bg-[#C9A84C] transition-all duration-400 ${
                      pathname === link.href ? 'w-full' : 'w-0 group-hover:w-full'
                    }`}
                  />
                </Link>
              </li>
            ))}
          </ul>

          {/* Desktop CTA */}
          <div className="hidden lg:flex items-center gap-5">
            <Link
              href="/dashboard"
              className={`text-[0.65rem] tracking-[0.22em] uppercase transition-colors duration-400 ${
                transparentTop
                  ? 'text-[#F5E6C8]/80 hover:text-[#E2C97E]'
                  : 'text-[#7A7068] hover:text-[#C9A84C]'
              }`}
              style={{ fontFamily: 'var(--font-jost)' }}
            >
              Client Login
            </Link>
            <Link href="/booking" className="btn-gold">
              <span>Start Planning</span>
            </Link>
          </div>

          {/* Mobile toggle */}
          <button
            className="lg:hidden p-2 z-10"
            onClick={() => setMenuOpen((v) => !v)}
            aria-label="Toggle menu"
          >
            {menuOpen ? (
              <X size={22} className={transparentTop && !menuOpen ? 'text-[#FFFDF7]' : 'text-[#2C2C2C]'} />
            ) : (
              <Menu
                size={22}
                className={transparentTop ? 'text-[#FFFDF7]' : 'text-[#2C2C2C]'}
              />
            )}
          </button>
        </div>
      </nav>

      {/* Mobile fullscreen menu */}
      <div
        className={`fixed inset-0 z-40 flex flex-col items-center justify-center bg-[#FFFDF7] transition-all duration-600 ${
          menuOpen
            ? 'opacity-100 pointer-events-auto'
            : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="flex flex-col items-center gap-2 text-center">
          <span
            className="text-3xl text-[#2C2C2C] mb-2 tracking-wide"
            style={{ fontFamily: 'var(--font-playfair)' }}
          >
            Veil &amp; Bloom
          </span>
          <div className="w-10 h-px bg-[#C9A84C] mb-6" />
          {navLinks.map((link, i) => (
            <Link
              key={link.href}
              href={link.href}
              className={`text-[0.78rem] tracking-[0.28em] uppercase py-3 transition-colors duration-300 ${
                pathname === link.href ? 'text-[#C9A84C]' : 'text-[#2C2C2C] hover:text-[#C9A84C]'
              }`}
              style={{
                fontFamily: 'var(--font-jost)',
                transitionDelay: `${i * 50}ms`,
              }}
            >
              {link.label}
            </Link>
          ))}
          <div className="w-10 h-px bg-[#C9A84C] mt-4 mb-6" />
          <Link href="/booking" className="btn-gold mb-4">
            <span>Start Planning</span>
          </Link>
          <Link
            href="/dashboard"
            className="text-[0.65rem] tracking-[0.22em] uppercase text-[#7A7068] hover:text-[#C9A84C] transition-colors"
            style={{ fontFamily: 'var(--font-jost)' }}
          >
            Client Login
          </Link>
        </div>

        <button
          className="absolute top-6 right-6 p-2"
          onClick={() => setMenuOpen(false)}
          aria-label="Close menu"
        >
          <X size={24} className="text-[#2C2C2C]" />
        </button>
      </div>
    </>
  )
}
