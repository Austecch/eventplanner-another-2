'use client'

import Link from 'next/link'
import { useEffect, useRef } from 'react'

export default function HomeCTA() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll('.reveal-on-scroll').forEach((el, i) => {
              setTimeout(() => el.classList.add('revealed'), i * 150)
            })
          }
        })
      },
      { threshold: 0.2 }
    )
    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={sectionRef as React.RefObject<HTMLElement>}
      className="relative py-40 px-6 overflow-hidden"
    >
      {/* Background Image */}
      <img
        src="https://placehold.co/1920x800?text=Aerial+view+luxury+wedding+reception+long+floral+table+candlelight+tented+outdoor+venue+golden+hour"
        alt="Aerial view of luxury wedding reception with long floral table and candlelight at golden hour"
        className="absolute inset-0 w-full h-full object-cover"
      />
      <div className="absolute inset-0 overlay-dark" />
      <div
        className="absolute inset-0"
        style={{ background: 'rgba(28,22,18,0.35)' }}
      />

      <div className="relative z-10 max-w-3xl mx-auto text-center">
        <div className="reveal-on-scroll inline-flex items-center gap-3 mb-8">
          <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
          <span className="text-[0.6rem] tracking-[0.4em] uppercase" style={{ color: '#E2C97E' }}>
            Begin Your Journey
          </span>
          <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
        </div>

        <h2
          className="text-4xl md:text-6xl lg:text-7xl leading-tight mb-8 reveal-on-scroll"
          style={{ fontFamily: 'var(--font-playfair)', color: '#FFFDF7' }}
        >
          Your Dream Wedding<br />
          <em style={{ color: '#C9A84C' }}>Starts With One Call</em>
        </h2>

        <p
          className="text-base md:text-lg mb-12 reveal-on-scroll"
          style={{
            color: '#F5E6C8',
            fontFamily: 'var(--font-jost)',
            fontWeight: 300,
            lineHeight: '1.9',
            letterSpacing: '0.04em',
          }}
        >
          Limited bookings accepted each year to ensure every couple receives
          our full dedication and artistry. Reach out today and let&apos;s
          begin crafting your perfect day.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 reveal-on-scroll">
          <Link href="/booking" className="btn-gold text-[0.72rem]">
            Request a Consultation
          </Link>
          <Link
            href="/contact"
            className="btn-outline-gold text-[0.72rem]"
            style={{ borderColor: 'rgba(226,201,126,0.5)', color: '#E2C97E' }}
          >
            Get in Touch
          </Link>
        </div>

        <p
          className="mt-8 text-[0.65rem] tracking-[0.15em] uppercase reveal-on-scroll"
          style={{ color: 'rgba(245,230,200,0.5)' }}
        >
          Available for 2025 &amp; 2026 Wedding Dates
        </p>
      </div>
    </section>
  )
}
