'use client'

import Link from 'next/link'
import { useEffect, useRef, useState } from 'react'
import { X, ChevronLeft, ChevronRight } from 'lucide-react'

const weddings = [
  {
    id: 1,
    title: 'Sophia & James',
    venue: 'Park Chateau Estate',
    style: 'Garden Romance',
    image: 'https://placehold.co/800x1000?text=Romantic+outdoor+garden+wedding+ceremony+bride+in+ivory+lace+gown+white+floral+arch+sunset+light',
    alt: 'Romantic outdoor garden wedding ceremony with bride in ivory lace gown under white floral arch at sunset',
    size: 'tall',
  },
  {
    id: 2,
    title: 'Elena & Marcus',
    venue: 'The Grand Ballroom, Morristown',
    style: 'Black Tie Elegance',
    image: 'https://placehold.co/800x600?text=Black+tie+ballroom+reception+gold+chandeliers+white+roses+tablescape+candlelight+gala+elegance',
    alt: 'Black tie ballroom reception with gold chandeliers, white roses tablescape and candlelight',
    size: 'wide',
  },
  {
    id: 3,
    title: 'Amara & Daniel',
    venue: 'Natirar Mansion',
    style: 'Rustic Luxe',
    image: 'https://placehold.co/800x800?text=Rustic+luxury+wedding+stone+mansion+grounds+wildflower+meadow+first+dance+amber+twilight',
    alt: 'Rustic luxury wedding at stone mansion grounds with wildflower meadow and first dance in amber twilight',
    size: 'square',
  },
  {
    id: 4,
    title: 'Claire & William',
    venue: 'Liberty House, Jersey City',
    style: 'Modern Minimalist',
    image: 'https://placehold.co/800x1000?text=Modern+minimalist+wedding+cityscape+backdrop+Manhattan+views+sleek+floral+white+and+gold+decor',
    alt: 'Modern minimalist wedding with Manhattan cityscape backdrop and sleek white and gold floral decor',
    size: 'tall',
  },
  {
    id: 5,
    title: 'Priya & Rohan',
    venue: 'Nanina\'s In The Park',
    style: 'South Asian Fusion',
    image: 'https://placehold.co/800x600?text=South+Asian+fusion+wedding+vibrant+marigold+garlands+ornate+mandap+golden+hour+photography',
    alt: 'South Asian fusion wedding with vibrant marigold garlands and ornate mandap in golden hour light',
    size: 'wide',
  },
]

export default function FeaturedWeddings() {
  const sectionRef = useRef<HTMLElement>(null)
  const [lightbox, setLightbox] = useState<number | null>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll('.reveal-on-scroll').forEach((el, i) => {
              setTimeout(() => el.classList.add('revealed'), i * 100)
            })
          }
        })
      },
      { threshold: 0.1 }
    )
    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setLightbox(null)
      if (e.key === 'ArrowRight' && lightbox !== null) setLightbox((l) => l !== null ? (l + 1) % weddings.length : null)
      if (e.key === 'ArrowLeft' && lightbox !== null) setLightbox((l) => l !== null ? (l - 1 + weddings.length) % weddings.length : null)
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [lightbox])

  return (
    <section
      ref={sectionRef as React.RefObject<HTMLElement>}
      className="py-32 px-6 lg:px-12"
      style={{ background: '#FFFDF7' }}
    >
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="reveal-on-scroll inline-flex items-center gap-3 mb-6">
              <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
              <span className="text-[0.6rem] tracking-[0.4em] uppercase" style={{ color: '#C9A84C' }}>
                Featured Work
              </span>
            </div>
            <h2
              className="text-4xl md:text-6xl reveal-on-scroll"
              style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}
            >
              Real Weddings,<br />
              <em>Real Magic</em>
            </h2>
          </div>
          <Link
            href="/portfolio"
            className="btn-outline-gold inline-block reveal-on-scroll self-start md:self-auto"
          >
            Full Portfolio
          </Link>
        </div>

        {/* Masonry Grid */}
        <div className="columns-1 sm:columns-2 lg:columns-3 gap-4 space-y-4">
          {weddings.map((wedding, i) => (
            <div
              key={wedding.id}
              className="break-inside-avoid reveal-on-scroll"
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div
                className="group relative overflow-hidden cursor-pointer"
                onClick={() => setLightbox(i)}
                style={{ border: '1px solid #E2D9CC' }}
              >
                <img
                  src={wedding.image}
                  alt={wedding.alt}
                  className="w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  style={{
                    height: wedding.size === 'tall' ? '480px' : wedding.size === 'square' ? '360px' : '280px',
                  }}
                />
                {/* Hover Overlay */}
                <div className="absolute inset-0 flex flex-col justify-end p-6 opacity-0 group-hover:opacity-100 transition-all duration-500"
                  style={{ background: 'linear-gradient(to top, rgba(28,22,18,0.85) 0%, transparent 50%)' }}
                >
                  <div
                    className="w-8 h-px mb-3"
                    style={{ background: '#C9A84C' }}
                  />
                  <h3
                    className="text-xl text-[#FFFDF7] mb-1"
                    style={{ fontFamily: 'var(--font-playfair)' }}
                  >
                    {wedding.title}
                  </h3>
                  <p
                    className="text-[0.65rem] tracking-[0.15em] uppercase"
                    style={{ color: '#E2C97E' }}
                  >
                    {wedding.venue} · {wedding.style}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightbox !== null && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center"
          style={{ background: 'rgba(28,22,18,0.95)' }}
          onClick={() => setLightbox(null)}
        >
          <button
            className="absolute top-6 right-6 text-[#F5E6C8] hover:text-[#C9A84C] transition-colors"
            onClick={() => setLightbox(null)}
            aria-label="Close lightbox"
          >
            <X size={28} />
          </button>
          <button
            className="absolute left-6 top-1/2 -translate-y-1/2 text-[#F5E6C8] hover:text-[#C9A84C] transition-colors"
            onClick={(e) => { e.stopPropagation(); setLightbox((l) => l !== null ? (l - 1 + weddings.length) % weddings.length : null) }}
            aria-label="Previous"
          >
            <ChevronLeft size={36} />
          </button>
          <div
            className="max-w-4xl max-h-[85vh] mx-16"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={weddings[lightbox].image}
              alt={weddings[lightbox].alt}
              className="max-w-full max-h-[70vh] object-contain"
            />
            <div className="text-center mt-4">
              <h3
                className="text-2xl mb-1"
                style={{ fontFamily: 'var(--font-playfair)', color: '#F5E6C8' }}
              >
                {weddings[lightbox].title}
              </h3>
              <p className="text-[0.65rem] tracking-[0.2em] uppercase" style={{ color: '#C9A84C' }}>
                {weddings[lightbox].venue} · {weddings[lightbox].style}
              </p>
            </div>
          </div>
          <button
            className="absolute right-6 top-1/2 -translate-y-1/2 text-[#F5E6C8] hover:text-[#C9A84C] transition-colors"
            onClick={(e) => { e.stopPropagation(); setLightbox((l) => l !== null ? (l + 1) % weddings.length : null) }}
            aria-label="Next"
          >
            <ChevronRight size={36} />
          </button>
        </div>
      )}
    </section>
  )
}
