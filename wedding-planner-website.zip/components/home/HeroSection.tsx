'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { ChevronDown } from 'lucide-react'

const heroSlides = [
  {
    image: 'https://placehold.co/1920x1080?text=Bride+and+groom+in+golden+hour+light+in+New+Jersey+garden+venue+with+soft+bokeh+and+floral+arch',
    alt: 'Bride and groom in golden hour light at a New Jersey garden venue with a floral arch',
    headline: 'Crafting Timeless',
    subline: 'Weddings in New Jersey',
    tagline: 'Where every love story becomes a cinematic masterpiece',
  },
  {
    image: 'https://placehold.co/1920x1080?text=Luxury+wedding+reception+table+with+ivory+and+gold+florals+crystal+chandeliers+and+candlelight',
    alt: 'Luxury wedding reception table with ivory and gold florals, crystal chandeliers and warm candlelight',
    headline: 'Designed with',
    subline: 'Intention & Grace',
    tagline: 'Meticulous details that speak to your unique love',
  },
  {
    image: 'https://placehold.co/1920x1080?text=Elegant+outdoor+wedding+ceremony+with+rose+petal+aisle+white+chairs+and+NJ+countryside+backdrop',
    alt: 'Elegant outdoor wedding ceremony with rose petal aisle and New Jersey countryside backdrop',
    headline: 'Every Moment',
    subline: 'Curated to Perfection',
    tagline: 'Luxury weddings crafted with soul across New Jersey',
  },
]

export default function HeroSection() {
  const [current, setCurrent] = useState(0)
  const [loaded, setLoaded] = useState(false)
  const [transitioning, setTransitioning] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setLoaded(true), 200)
    return () => clearTimeout(t)
  }, [])

  useEffect(() => {
    const interval = setInterval(() => {
      setTransitioning(true)
      setTimeout(() => {
        setCurrent((c) => (c + 1) % heroSlides.length)
        setTransitioning(false)
      }, 700)
    }, 6000)
    return () => clearInterval(interval)
  }, [])

  const slide = heroSlides[current]

  return (
    <section
      className="relative w-full overflow-hidden"
      style={{ height: '100svh', minHeight: '640px' }}
      aria-label="Hero section"
    >
      {/* Slides */}
      {heroSlides.map((s, i) => (
        <div
          key={i}
          className="absolute inset-0 transition-opacity duration-1000"
          style={{ opacity: i === current ? 1 : 0 }}
        >
          <img
            src={s.image}
            alt={s.alt}
            className="w-full h-full object-cover animate-pan"
          />
        </div>
      ))}

      {/* Dark overlay */}
      <div className="absolute inset-0 overlay-dark" />

      {/* Grain texture overlay */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 256 256\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noise\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.9\' numOctaves=\'4\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noise)\' opacity=\'0.04\'/%3E%3C/svg%3E")',
          opacity: 0.4,
        }}
      />

      {/* Content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-6">
        <div
          className={`transition-all duration-700 ${loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
        >
          {/* Badge */}
          <div
            className="inline-flex items-center gap-3 mb-8"
            style={{ opacity: loaded ? 1 : 0, transition: 'opacity 0.8s ease 0.3s' }}
          >
            <div className="w-8 h-px" style={{ background: '#C9A84C' }} />
            <span
              className="text-[0.6rem] tracking-[0.4em] uppercase"
              style={{ color: '#E2C97E' }}
            >
              New Jersey&apos;s Premier Wedding Studio
            </span>
            <div className="w-8 h-px" style={{ background: '#C9A84C' }} />
          </div>

          {/* Main Headline */}
          <h1
            className={`text-6xl sm:text-7xl md:text-8xl lg:text-9xl leading-none mb-4 transition-all duration-700 ${
              transitioning ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'
            }`}
            style={{
              fontFamily: 'var(--font-playfair), Playfair Display, serif',
              color: '#FFFDF7',
              fontStyle: 'italic',
              textShadow: '0 2px 40px rgba(0,0,0,0.3)',
            }}
          >
            {slide.headline}
          </h1>
          <h1
            className={`text-6xl sm:text-7xl md:text-8xl lg:text-9xl leading-none mb-8 transition-all duration-700 delay-75 ${
              transitioning ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'
            }`}
            style={{
              fontFamily: 'var(--font-playfair), Playfair Display, serif',
              color: '#C9A84C',
              textShadow: '0 2px 40px rgba(0,0,0,0.3)',
            }}
          >
            {slide.subline}
          </h1>

          {/* Tagline */}
          <p
            className={`text-base md:text-lg max-w-lg mx-auto mb-12 transition-all duration-700 delay-100 ${
              transitioning ? 'opacity-0' : 'opacity-100'
            }`}
            style={{
              color: '#F5E6C8',
              fontFamily: 'var(--font-jost)',
              fontWeight: 300,
              letterSpacing: '0.06em',
            }}
          >
            {slide.tagline}
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/booking" className="btn-gold text-[0.72rem]">
              Start Planning Your Day
            </Link>
            <Link
              href="/portfolio"
              className="btn-outline-gold text-[0.72rem]"
              style={{ borderColor: 'rgba(226,201,126,0.6)', color: '#E2C97E' }}
            >
              View Our Work
            </Link>
          </div>
        </div>
      </div>

      {/* Slide Indicators */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex gap-2">
        {heroSlides.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            className="transition-all duration-300"
            style={{
              width: i === current ? '2rem' : '0.4rem',
              height: '2px',
              background: i === current ? '#C9A84C' : 'rgba(255,253,247,0.4)',
            }}
            aria-label={`Go to slide ${i + 1}`}
          />
        ))}
      </div>

      {/* Scroll Down */}
      <a
        href="#about"
        className="absolute bottom-10 right-8 flex flex-col items-center gap-2 transition-opacity hover:opacity-70"
        aria-label="Scroll to about section"
      >
        <span
          className="text-[0.55rem] tracking-[0.3em] uppercase"
          style={{ color: '#E2C97E', writingMode: 'vertical-rl' }}
        >
          Scroll
        </span>
        <ChevronDown size={16} style={{ color: '#C9A84C' }} className="animate-bounce" />
      </a>
    </section>
  )
}
