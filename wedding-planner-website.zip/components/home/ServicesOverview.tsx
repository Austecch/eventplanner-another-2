'use client'

import Link from 'next/link'
import { useEffect, useRef } from 'react'
import { ArrowRight } from 'lucide-react'

const services = [
  {
    title: 'Full Wedding Planning',
    description:
      'From the first vision board to the final farewell dance — we handle every exquisite detail of your entire wedding journey.',
    image: 'https://placehold.co/600x700?text=Full+wedding+planning+consultation+with+elegant+floral+samples+invitation+suites+and+champagne+glasses',
    alt: 'Full wedding planning consultation with elegant floral samples, invitation suites and champagne glasses',
    tag: 'Most Popular',
    href: '/services#full-planning',
  },
  {
    title: 'Partial Planning',
    description:
      'Already started planning? Let us step in and elevate what you have, coordinating vendors and perfecting logistics.',
    image: 'https://placehold.co/600x700?text=Wedding+planner+reviewing+floor+plans+with+couple+at+upscale+NJ+venue+with+natural+light',
    alt: 'Wedding planner reviewing floor plans with couple at upscale New Jersey venue',
    tag: 'Flexible',
    href: '/services#partial-planning',
  },
  {
    title: 'Day-of Coordination',
    description:
      'Your vision, our execution. We take the reins on your wedding day so you can be fully present in every precious moment.',
    image: 'https://placehold.co/600x700?text=Day+of+coordinator+organizing+ceremony+setup+with+floral+arrangements+and+elegant+tablescapes',
    alt: 'Day-of coordinator organizing ceremony setup with floral arrangements and elegant tablescapes',
    tag: 'Stress-Free',
    href: '/services#day-of',
  },
  {
    title: 'Destination Weddings',
    description:
      'Dream of exchanging vows somewhere extraordinary? We orchestrate seamless destination weddings across the globe.',
    image: 'https://placehold.co/600x700?text=Destination+wedding+ceremony+on+tropical+beach+with+white+draping+and+ocean+backdrop+at+sunset',
    alt: 'Destination wedding ceremony on tropical beach with white draping and ocean backdrop at sunset',
    tag: 'Worldwide',
    href: '/services#destination',
  },
]

export default function ServicesOverview() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll('.reveal-on-scroll').forEach((el, i) => {
              setTimeout(() => el.classList.add('revealed'), i * 100)
            })
          }
        })
      },
      { threshold: 0.1 }
    )
    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={sectionRef as React.RefObject<HTMLElement>}
      className="py-32 px-6 lg:px-12"
      style={{ background: '#FAF6EF' }}
    >
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-20">
          <div className="reveal-on-scroll inline-flex items-center gap-3 mb-6">
            <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
            <span className="text-[0.6rem] tracking-[0.4em] uppercase" style={{ color: '#C9A84C' }}>
              Our Services
            </span>
            <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
          </div>
          <h2
            className="text-4xl md:text-6xl reveal-on-scroll"
            style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}
          >
            Tailored to Every <em>Love Story</em>
          </h2>
          <p
            className="max-w-xl mx-auto mt-6 text-base leading-relaxed reveal-on-scroll"
            style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.9' }}
          >
            Whether you need full orchestration or a guiding hand on the day itself,
            we offer services designed to match your needs and exceed your expectations.
          </p>
        </div>

        {/* Cards Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, i) => (
            <div
              key={service.title}
              className="group reveal-on-scroll card-luxury overflow-hidden"
              style={{
                background: '#FFFDF7',
                border: '1px solid #E2D9CC',
                transitionDelay: `${i * 80}ms`,
              }}
            >
              {/* Image */}
              <div className="overflow-hidden" style={{ height: '280px' }}>
                <img
                  src={service.image}
                  alt={service.alt}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
              </div>

              {/* Content */}
              <div className="p-6">
                <div
                  className="inline-block text-[0.55rem] tracking-[0.25em] uppercase px-3 py-1 mb-4"
                  style={{ background: '#F5E6C8', color: '#9B7A2F' }}
                >
                  {service.tag}
                </div>
                <h3
                  className="text-xl mb-3"
                  style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}
                >
                  {service.title}
                </h3>
                <p
                  className="text-sm leading-relaxed mb-6"
                  style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.8' }}
                >
                  {service.description}
                </p>
                <Link
                  href={service.href}
                  className="inline-flex items-center gap-2 text-[0.7rem] tracking-[0.15em] uppercase transition-all duration-300 group-hover:gap-3"
                  style={{ color: '#C9A84C' }}
                >
                  Learn More
                  <ArrowRight size={13} className="transition-transform duration-300 group-hover:translate-x-1" />
                </Link>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-16 reveal-on-scroll">
          <Link href="/services" className="btn-gold inline-block">
            Explore All Services
          </Link>
        </div>
      </div>
    </section>
  )
}
