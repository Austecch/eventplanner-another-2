'use client'

import Link from 'next/link'
import { useEffect, useRef } from 'react'

const stats = [
  { number: '12+', label: 'Years of Excellence' },
  { number: '300+', label: 'Weddings Curated' },
  { number: '98%', label: 'Client Satisfaction' },
  { number: '50+', label: 'NJ Venues' },
]

export default function AboutPreview() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll('.reveal-on-scroll').forEach((el, i) => {
              setTimeout(() => el.classList.add('revealed'), i * 120)
            })
          }
        })
      },
      { threshold: 0.15 }
    )
    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section
      id="about"
      ref={sectionRef as React.RefObject<HTMLElement>}
      className="py-32 px-6 lg:px-12"
      style={{ background: '#FFFDF7' }}
    >
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          {/* Image Side */}
          <div className="relative reveal-on-scroll">
            <div
              className="absolute -top-6 -left-6 w-48 h-48 border z-0"
              style={{ borderColor: '#E2C97E', opacity: 0.3 }}
            />
            <div className="relative z-10 overflow-hidden">
              <img
                src="https://placehold.co/700x900?text=Elegant+wedding+planner+studio+with+mood+boards+champagne+florals+and+soft+natural+light+in+NJ"
                alt="Veil and Bloom wedding planning studio with elegant mood boards and champagne florals"
                className="w-full object-cover"
                style={{ height: '560px' }}
              />
            </div>
            {/* Floating accent card */}
            <div
              className="absolute -bottom-8 -right-8 z-20 p-6 shadow-2xl"
              style={{ background: '#FFFDF7', border: '1px solid #E2D9CC' }}
            >
              <p
                className="text-[0.6rem] tracking-[0.3em] uppercase mb-2"
                style={{ color: '#C9A84C' }}
              >
                Featured In
              </p>
              <div className="flex flex-col gap-1">
                {['The Knot', 'Brides Magazine', 'Martha Stewart Weddings'].map((pub) => (
                  <span
                    key={pub}
                    className="text-xs"
                    style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300 }}
                  >
                    {pub}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Text Side */}
          <div>
            <div className="reveal-on-scroll">
              <div className="section-divider">
                <span
                  className="text-[0.6rem] tracking-[0.35em] uppercase"
                  style={{ color: '#C9A84C', flexShrink: 0 }}
                >
                  Our Story
                </span>
              </div>
            </div>

            <h2
              className="text-4xl md:text-5xl lg:text-6xl leading-tight mb-8 reveal-on-scroll"
              style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}
            >
              We Don&apos;t Just Plan Weddings.{' '}
              <em className="gold-text">We Create Memories.</em>
            </h2>

            <p
              className="text-base leading-relaxed mb-6 reveal-on-scroll"
              style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.9' }}
            >
              Veil &amp; Bloom was founded on a simple belief: your wedding day should feel like the
              most beautifully orchestrated film of your life. Every glance, every breath, every
              carefully placed petal — all of it deserves to be flawlessly executed.
            </p>

            <p
              className="text-base leading-relaxed mb-10 reveal-on-scroll"
              style={{ color: '#7A7068', fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.9' }}
            >
              Based in Princeton, New Jersey, our team of dedicated planners brings over a decade
              of luxury event experience to every single celebration we touch.
            </p>

            <Link href="/about" className="btn-outline-gold inline-block reveal-on-scroll">
              Meet Our Team
            </Link>
          </div>
        </div>

        {/* Stats Row */}
        <div
          className="grid grid-cols-2 lg:grid-cols-4 gap-8 mt-24 pt-16 border-t"
          style={{ borderColor: '#E2D9CC' }}
        >
          {stats.map((stat, i) => (
            <div key={stat.label} className={`text-center reveal-on-scroll`} style={{ transitionDelay: `${i * 100}ms` }}>
              <div
                className="text-4xl md:text-5xl mb-2 gold-shimmer"
                style={{ fontFamily: 'var(--font-playfair)' }}
              >
                {stat.number}
              </div>
              <div
                className="text-[0.65rem] tracking-[0.2em] uppercase"
                style={{ color: '#B5AFA8' }}
              >
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
