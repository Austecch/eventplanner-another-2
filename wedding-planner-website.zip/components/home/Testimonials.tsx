'use client'

import { useState, useEffect, useRef } from 'react'
import { ChevronLeft, ChevronRight, Star } from 'lucide-react'

const testimonials = [
  {
    name: 'Sophia & James Hartley',
    venue: 'Park Chateau Estate, East Brunswick',
    date: 'September 2024',
    quote:
      '"Veil & Bloom turned what could have been an overwhelming process into the most magical experience of our lives. Not a single detail was overlooked. Our wedding felt like a film — cinematic, emotional, and absolutely flawless."',
    image: 'https://placehold.co/80x80?text=Couple+portrait+close+up+with+soft+bokeh+background+natural+light+smiling',
    alt: 'Sophia and James Hartley wedding couple portrait',
    rating: 5,
  },
  {
    name: 'Elena & Marcus Chen',
    venue: 'The Grand Ballroom, Morristown',
    date: 'June 2024',
    quote:
      '"From the very first call, we knew Veil & Bloom was different. They truly listened to us and created something that was uniquely ours. The florals, the lighting, the table settings — every element was thoughtfully executed to perfection."',
    image: 'https://placehold.co/80x80?text=Asian+American+bride+and+groom+portrait+elegant+formal+attire+warm+tones',
    alt: 'Elena and Marcus Chen wedding portrait',
    rating: 5,
  },
  {
    name: 'Amara & Daniel Osei',
    venue: 'Natirar Mansion, Peapack',
    date: 'October 2024',
    quote:
      '"I cannot imagine our day without the Veil & Bloom team. They understood our vision better than we did ourselves. The way they blended our cultural traditions with modern luxury was breathtaking. Worth every penny."',
    image: 'https://placehold.co/80x80?text=African+American+wedding+couple+portrait+bride+with+natural+flowers+golden+sunset',
    alt: 'Amara and Daniel Osei wedding portrait',
    rating: 5,
  },
  {
    name: 'Claire & William Brooks',
    venue: 'Liberty House, Jersey City',
    date: 'April 2024',
    quote:
      '"The attention to detail was extraordinary. Our guests are still talking about the experience — the entrance, the music transitions, the lighting. Veil & Bloom creates events that are felt, not just seen."',
    image: 'https://placehold.co/80x80?text=Classic+elegant+wedding+couple+portrait+black+tuxedo+white+gown+chandeliers',
    alt: 'Claire and William Brooks wedding portrait',
    rating: 5,
  },
]

export default function Testimonials() {
  const [current, setCurrent] = useState(0)
  const [transitioning, setTransitioning] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)
  const autoRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const go = (direction: number) => {
    if (transitioning) return
    setTransitioning(true)
    setTimeout(() => {
      setCurrent((c) => (c + direction + testimonials.length) % testimonials.length)
      setTransitioning(false)
    }, 400)
    if (autoRef.current) clearInterval(autoRef.current)
    startAuto()
  }

  const startAuto = () => {
    autoRef.current = setInterval(() => {
      setTransitioning(true)
      setTimeout(() => {
        setCurrent((c) => (c + 1) % testimonials.length)
        setTransitioning(false)
      }, 400)
    }, 7000)
  }

  useEffect(() => {
    startAuto()
    return () => { if (autoRef.current) clearInterval(autoRef.current) }
  }, [])

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll('.reveal-on-scroll').forEach((el, i) => {
              setTimeout(() => el.classList.add('revealed'), i * 100)
            })
          }
        })
      },
      { threshold: 0.15 }
    )
    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  const t = testimonials[current]

  return (
    <section
      ref={sectionRef as React.RefObject<HTMLElement>}
      className="py-32 px-6 lg:px-12 relative overflow-hidden"
      style={{ background: '#FAF6EF' }}
    >
      {/* Large background letter */}
      <div
        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-[30rem] leading-none pointer-events-none select-none"
        style={{
          fontFamily: 'var(--font-playfair)',
          color: 'rgba(201,168,76,0.04)',
        }}
      >
        &ldquo;
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="reveal-on-scroll inline-flex items-center gap-3 mb-6">
            <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
            <span className="text-[0.6rem] tracking-[0.4em] uppercase" style={{ color: '#C9A84C' }}>
              Client Love
            </span>
            <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
          </div>
          <h2
            className="text-4xl md:text-6xl reveal-on-scroll"
            style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}
          >
            Stories from Our<br />
            <em>Happy Couples</em>
          </h2>
        </div>

        {/* Testimonial Card */}
        <div
          className={`text-center transition-all duration-400 ${
            transitioning ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'
          }`}
        >
          {/* Stars */}
          <div className="flex justify-center gap-1 mb-8">
            {Array.from({ length: t.rating }).map((_, i) => (
              <Star key={i} size={16} fill="#C9A84C" color="#C9A84C" />
            ))}
          </div>

          {/* Quote */}
          <blockquote
            className="text-lg md:text-xl lg:text-2xl leading-relaxed mb-10"
            style={{
              fontFamily: 'var(--font-playfair)',
              color: '#2C2C2C',
              fontStyle: 'italic',
              lineHeight: '1.8',
            }}
          >
            {t.quote}
          </blockquote>

          {/* Author */}
          <div className="flex flex-col items-center gap-3">
            <img
              src={t.image}
              alt={t.alt}
              className="w-16 h-16 rounded-full object-cover"
              style={{ border: '2px solid #C9A84C' }}
            />
            <div>
              <div
                className="text-base font-medium"
                style={{ fontFamily: 'var(--font-playfair)', color: '#2C2C2C' }}
              >
                {t.name}
              </div>
              <div
                className="text-[0.65rem] tracking-[0.15em] uppercase mt-1"
                style={{ color: '#B5AFA8' }}
              >
                {t.venue} · {t.date}
              </div>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-6 mt-12">
          <button
            onClick={() => go(-1)}
            className="w-12 h-12 border flex items-center justify-center transition-all duration-300 hover:border-[#C9A84C] hover:text-[#C9A84C]"
            style={{ borderColor: '#E2D9CC', color: '#7A7068' }}
            aria-label="Previous testimonial"
          >
            <ChevronLeft size={18} />
          </button>

          <div className="flex gap-2">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className="transition-all duration-300"
                style={{
                  width: i === current ? '1.5rem' : '0.4rem',
                  height: '2px',
                  background: i === current ? '#C9A84C' : '#D8D0C8',
                }}
                aria-label={`Testimonial ${i + 1}`}
              />
            ))}
          </div>

          <button
            onClick={() => go(1)}
            className="w-12 h-12 border flex items-center justify-center transition-all duration-300 hover:border-[#C9A84C] hover:text-[#C9A84C]"
            style={{ borderColor: '#E2D9CC', color: '#7A7068' }}
            aria-label="Next testimonial"
          >
            <ChevronRight size={18} />
          </button>
        </div>
      </div>
    </section>
  )
}
