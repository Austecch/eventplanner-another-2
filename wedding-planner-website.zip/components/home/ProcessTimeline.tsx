'use client'

import { useEffect, useRef } from 'react'

const steps = [
  {
    number: '01',
    title: 'Discovery Call',
    description:
      'We begin with an intimate conversation to understand your vision, style, and the feeling you want your day to embody.',
    duration: '30 min',
  },
  {
    number: '02',
    title: 'Vision & Design',
    description:
      'Our team curates a bespoke mood board, color palette, and design concept that perfectly captures your love story.',
    duration: '1–2 weeks',
  },
  {
    number: '03',
    title: 'Vendor Curation',
    description:
      'We hand-select and negotiate with our exclusive network of New Jersey\'s finest photographers, florists, and caterers.',
    duration: '2–4 weeks',
  },
  {
    number: '04',
    title: 'Planning & Logistics',
    description:
      'From venue layouts to guest transportation — every logistical detail is meticulously planned and confirmed.',
    duration: 'Ongoing',
  },
  {
    number: '05',
    title: 'Your Perfect Day',
    description:
      'We orchestrate every beautiful moment while you are completely present, relaxed, and immersed in the magic.',
    duration: 'Wedding Day',
  },
]

export default function ProcessTimeline() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll('.reveal-on-scroll').forEach((el, i) => {
              setTimeout(() => el.classList.add('revealed'), i * 150)
            })
          }
        })
      },
      { threshold: 0.1 }
    )
    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={sectionRef as React.RefObject<HTMLElement>}
      className="py-32 px-6 lg:px-12 relative overflow-hidden"
      style={{ background: '#1C1610' }}
    >
      {/* Background texture */}
      <div
        className="absolute inset-0 pointer-events-none opacity-5"
        style={{
          backgroundImage: 'repeating-linear-gradient(0deg, #C9A84C, #C9A84C 1px, transparent 1px, transparent 60px), repeating-linear-gradient(90deg, #C9A84C, #C9A84C 1px, transparent 1px, transparent 60px)',
        }}
      />

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header */}
        <div className="text-center mb-20">
          <div className="reveal-on-scroll inline-flex items-center gap-3 mb-6">
            <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
            <span className="text-[0.6rem] tracking-[0.4em] uppercase" style={{ color: '#C9A84C' }}>
              Our Process
            </span>
            <div className="w-10 h-px" style={{ background: '#C9A84C' }} />
          </div>
          <h2
            className="text-4xl md:text-6xl reveal-on-scroll"
            style={{ fontFamily: 'var(--font-playfair)', color: '#F5E6C8' }}
          >
            From Vision to<br />
            <em style={{ color: '#C9A84C' }}>Reality</em>
          </h2>
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Connecting line */}
          <div
            className="hidden lg:block absolute left-1/2 top-0 bottom-0 w-px -translate-x-1/2"
            style={{ background: 'linear-gradient(to bottom, transparent, #C9A84C 15%, #C9A84C 85%, transparent)' }}
          />

          <div className="space-y-12 lg:space-y-0">
            {steps.map((step, i) => (
              <div
                key={step.number}
                className={`relative lg:grid lg:grid-cols-2 lg:gap-16 lg:items-center reveal-on-scroll ${
                  i % 2 === 0 ? '' : 'lg:direction-rtl'
                }`}
                style={{ transitionDelay: `${i * 120}ms` }}
              >
                {/* Content */}
                <div
                  className={`lg:text-${i % 2 === 0 ? 'right' : 'left'} ${
                    i % 2 !== 0 ? 'lg:col-start-2' : ''
                  } pb-12 lg:pb-16`}
                >
                  <div
                    className={`flex items-center gap-4 mb-4 ${
                      i % 2 === 0 ? 'lg:justify-end' : 'lg:justify-start'
                    }`}
                  >
                    <span
                      className="text-[0.55rem] tracking-[0.3em] uppercase px-3 py-1"
                      style={{ background: 'rgba(201,168,76,0.15)', color: '#C9A84C', border: '1px solid rgba(201,168,76,0.3)' }}
                    >
                      {step.duration}
                    </span>
                  </div>
                  <h3
                    className="text-2xl md:text-3xl mb-4"
                    style={{ fontFamily: 'var(--font-playfair)', color: '#F5E6C8' }}
                  >
                    {step.title}
                  </h3>
                  <p
                    className="text-sm leading-relaxed"
                    style={{ color: '#B5AFA8', fontFamily: 'var(--font-jost)', fontWeight: 300, lineHeight: '1.9' }}
                  >
                    {step.description}
                  </p>
                </div>

                {/* Center dot */}
                <div className="hidden lg:flex absolute left-1/2 top-6 -translate-x-1/2 items-center justify-center">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center border-2"
                    style={{ background: '#1C1610', borderColor: '#C9A84C' }}
                  >
                    <span
                      className="text-xs font-medium"
                      style={{ color: '#C9A84C', fontFamily: 'var(--font-jost)' }}
                    >
                      {step.number}
                    </span>
                  </div>
                </div>

                {/* Mobile number */}
                <div
                  className="lg:hidden text-6xl mb-4"
                  style={{
                    fontFamily: 'var(--font-playfair)',
                    color: 'rgba(201,168,76,0.15)',
                    lineHeight: 1,
                  }}
                >
                  {step.number}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
